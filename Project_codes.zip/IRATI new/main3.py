# Main code for plotting the planets and asteroids of the Solar System
# Irati Cadenato & Giacomo Vargiu
# Interplanetary trajectory Design and Optimization 2024/2025

import matplotlib.pyplot as plt
from functions_plan import to_julian, position, julian_day
from functions_ast import position_ast
from functions_main import plot_main
from functions_transf import plot_transfer_3D, plot_transfer_2D
from functions_optimization import UPC_ITDO24Q2_MGAPGA_AGA, julian_century

# Insert the initial (departure) date here (1st planet)
Y1 = 1975
M1 = 8
D1 = 20
utch1 = 0.0
utcm1 = 0.0
utcs1 = 0.0
JD1, JC1 = to_julian(Y1, M1, D1, utch1, utcm1, utcs1)

plt.style.use('dark_background')

# File path for the database of asteroids
file_path = "Databases/astorb_200.txt" 
planets = position(JC1)
asteroids = position_ast(JD1, file_path)

plot_main(planets, asteroids, D1, M1, Y1)

# 2. Inner planets: Mercury (1), Venus (2), Earth (3), Mars (4), Jupiter (5)
inner_planets = {k: planets[k] for k in (1, 2, 3, 4, 5)}
plot_main(inner_planets, asteroids, D1, M1, Y1)

# 3. Outer planets: Jupiter (5), Saturn (6), Uranus (7), Neptune (8)
outer_planets = {k: planets[k] for k in (5, 6, 7, 8)}
plot_main(outer_planets, asteroids, D1, M1, Y1)

# =============================================================================
# Project II: Swinging By!
# =============================================================================
# =============================================================================
# Part A: Transfer orbit
# =============================================================================

# Insert the final (arrival) date here (2nd planet)
Y2 = 1976
M2 = 6
D2 = 19
utch2 = 0.0
utcm2 = 0.0
utcs2 = 0.0
JD2, JC2 = to_julian(Y2, M2, D2, utch2, utcm2, utcs2)
tof_days = (JD2 - JD1) # in days
tof_sec = tof_days * 24 * 3600 # in s
mu = 1.327e20 # m^3/s^2
AU = 149597870700  # 1 AU en metros

# Mercury = 1, Venus = 2, Earth = 3, Mars = 4, Jupiter = 5, Saturn = 6, Uranus = 7, Neptune = 8
departure_planet = 3
arrival_planet = 4

# plot in 2D
plot_transfer_2D(JC1, JC2, departure_planet, arrival_planet, tof_sec)
# plot in 3D
h_transfer1, intersection_SOI_dep1, intersection_SOI_arr1, v_dep_transfer1, v_arr_transfer1 = plot_transfer_3D(JC1, JC2, departure_planet, arrival_planet, tof_sec)
#h_transfer1, intersection_SOI_dep1, intersection_SOI_arr1, v_dep_transfer1, v_arr_transfer1 = plot_transfer_3D(julian_century(2464655.3), julian_century(2464655.3 + 928.7), departure_planet, arrival_planet, 928.7 * 24 * 3600)

# =============================================================================
# Part B: Gravity assist
# =============================================================================

# Insert the next (arrival) date here (3rd planet)
# Y3 = 0
# M3 = 0
# D3 = 0
# utch3 = 0.0
# utcm3 = 0.0
# utcs3 = 0.0
# JD3, JC3 = to_julian(Y3, M3, D3, utch3, utcm3, utcs3)
# tof_days3 = (JD3 - JD2) # in days
# tof_sec3 = tof_days3 * 24 * 3600 # in s

# =============================================================================
# Project III: The Voyage (Optimization)
# =============================================================================

planet_names = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
planets = [planet_names[departure_planet-1], planet_names[arrival_planet-1]]
tof_days_minmax = [30.0, tof_days]
# jd2k0_days = []
# jd2k0_days_aux1 = julian_day(JC1)
# jd2k0_days_aux2 = julian_day(JC2)
# jd2k0_days.append(jd2k0_days_aux1)
# jd2k0_days.append(jd2k0_days_aux2)
jd2k0_days = [JD1, JD1 + 30.0 * 24] # minimum 1 month maximum 2 years for the departure date from today

# Scenario boundaries
#jd2k0_days is the boundaries [min, max] for departure dates (in days) relative to J2000
#tofs_days is the boundaries [min, max] for TOF for each trajectory leg in days

UPC_ITDO24Q2_MGAPGA_AGA(planets, jd2k0_days, tof_days_minmax)






