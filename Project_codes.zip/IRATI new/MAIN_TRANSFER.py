#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Mar 12 12:43:28 2025

@author: giacomovargiu
"""
import numpy as np
from Lambert_Bate import Lambert_Bate_1971_Z_BI_FG_SIMPLE
from Transfer_orbits import compute_orbital_elements
from Plot_orbit import plot_orbit
from Planet_vectors import state_vector, to_julian, planet_OP



mu = mu = 1.32712440018e20
lw = 0  # Short-way transfer
tol = 1e-6

# Insert the departure date here
Y1 = 2025
M1 = 2
D1 = 28
utch1 = 0.0
utcm1 = 0.0
utcs1 = 0.0
julian_day1, julian_century1 = to_julian(Y1, M1, D1, utch1, utcm1, utcs1)
# Insert the arrrival date here
Y2 = 2025
M2 = 7
D2 = 28
utch2 = 0.0
utcm2 = 0.0
utcs2 = 0.0
julian_day2, julian_century2 = to_julian(Y2, M2, D2, utch2, utcm2, utcs2)
tof_trans = (julian_day2 - julian_day1) * 24 * 3600

# Mercury = 1, Venus = 2, Earth = 3, Mars = 4, Jupiter = 5, Saturn = 6, Uranus = 7, Neptune = 8
departure_planet = 3
arrival_planet = 4

#  Orbital parameters of each planet
departure_OP = planet_OP(departure_planet)
arrival_OP = planet_OP(arrival_planet)

r1, v1, theta1 = state_vector(departure_OP, julian_century1)
r2, v2, theta2 = state_vector(arrival_OP, julian_century2)

print(r1)
print(r2)

# a1, e1, i1, Omega1, omega1, theta1 = compute_orbital_elements(r1,v1,mu)
# a2, e2, i2, Omega2, omega2, theta2 = compute_orbital_elements(r2,v2,mu)

a1, e1, i1_deg, Omega1_deg, omega1_deg, theta1_deg = compute_orbital_elements(r1,v1,mu)
a2, e2, i2_deg, Omega2_deg, omega2_deg, theta2_deg = compute_orbital_elements(r2,v2,mu)

i1 = np.radians(i1_deg)
Omega1 = np.radians(Omega1_deg)
omega1 = np.radians(omega1_deg)
theta1 = np.radians(theta1_deg)
i2 = np.radians(i2_deg)
Omega2 = np.radians(Omega2_deg)
omega2 = np.radians(omega2_deg)
theta2 = np.radians(theta2_deg)

v1_trans, v2_trans = Lambert_Bate_1971_Z_BI_FG_SIMPLE(r1, r2, tof_trans, mu, lw, tol)

# a_trans, e_trans, i_trans, Omega_trans, omega_trans, theta_trans = compute_orbital_elements(r1,v1_trans,mu)

a_trans, e_trans, i_trans_deg, Omega_trans_deg, omega_trans_deg, theta_trans_deg = compute_orbital_elements(r1,v1_trans,mu)

i_trans = np.radians(i_trans_deg)
Omega_trans = np.radians(Omega_trans_deg)
omega_trans = np.radians(omega_trans_deg)
theta_trans = np.radians(theta_trans_deg)

print(e1)
print(e2)
print(e_trans)

print(i1)
print(i2)
print(i_trans)

plot_orbit(a_trans, e_trans, i_trans, Omega_trans, omega_trans, r1, a1, e1, i1, Omega1, omega1, r2, a2, e2, i2, Omega2, omega2)

#print(a_trans)
#print(e_trans)
#print(i_trans_deg)
#print(Omega_trans_deg)
#print(omega_trans_deg)
#print(theta_trans_deg)
#print(theta2_deg)