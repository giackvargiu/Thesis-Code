#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 28 11:36:00 2025

@author: giacomovargiu
"""

import numpy as np
from functions_plan import state_vector
#from Lambert_Bate import Lambert_Bate_1971_Z_BI_FG_SIMPLE
from lambert_izzo_2015_x_hh_rt_norel import lambert_izzo_2015_x_hh_rt_norel

def julian_century(JD):
    JC = (JD - 2451545) / 36525
    return JC

def from_julian(JD):
    """
    Convierte un Julian Date (JD) a fecha Gregoriana (año, mes, día, hora, minuto, segundo).

    Parámetros:
    -----------
    JD : float
        Julian Date.

    Devuelve:
    --------
    year, month, day, hour, minute, second : int, int, int, int, int, float
        Componentes de la fecha Gregoriana correspondiente.
    """
    # Paso 1: deshacer el offset de medio día
    J = JD + 0.5
    Z = int(J)
    F = J - Z

    # Paso 2: corrección según calendario Gregoriano
    if Z < 2299161:
        A = Z
    else:
        alpha = int((Z - 1867216.25) / 36524.25)
        A = Z + 1 + alpha - int(alpha / 4)

    # Paso 3: reconstruir año/mes/día
    B = A + 1524
    C = int((B - 122.1) / 365.25)
    D = int(365.25 * C)
    E = int((B - D) / 30.6001)

    # Día con fracción
    day_frac = B - D - int(30.6001 * E) + F
    day = int(day_frac)

    # Mes
    if E < 14:
        month = E - 1
    else:
        month = E - 13

    # Año
    if month > 2:
        year = C - 4716
    else:
        year = C - 4715

    # Paso 4: separar la fracción de día en h/m/s
    frac_day = day_frac - day
    hours = frac_day * 24
    hour = int(hours)
    minutes = (hours - hour) * 60
    minute = int(minutes)
    seconds = (minutes - minute) * 60

    return year, month, day, hour, minute, seconds


def departure_dates(dep_date, tofs):
    """
    Calcula y guarda en una lista todas las fechas de salida (departure dates) en días julianos.

    Parámetros:
    dep_date (float): Fecha de salida inicial en días julianos.
    tofs (list of float): Lista de tiempos de vuelo (TOF) entre los planetas en días.

    Retorna:
    dep_dates (list of float): Lista con todas las fechas de salida en días julianos.
    """
    dep_dates = [dep_date]  # Iniciar la lista con la fecha de salida inicial

    for tof in tofs[:-1]: # del último elemento de la lista no se sale
        dep_date += tof  # Calcular la nueva fecha de salida
        dep_dates.append(dep_date)  # Guardar en la lista

    return dep_dates

def deltaV_arc(v1_planet, v2_planet, v1_transfer, v2_transfer):
    """
    Calculates the Delta-V-s of an arc given the transfer velocities and the velocity of the planets
    ----------
    v1_transfer : velocity of the transfer arc in the departure
    v2_transfer : velocity of the transfer arc in the arrival
    v1_planet : velocity of departure planet
    v2_planet : velocity of arrival planet
    Returns
    -------
    deltaV1_arc : Delta_V at departure of the arc
    deltaV2_arc : Delta_V at arrival of the arc

    """
    deltaV1_arc = np.linalg.norm(v1_transfer - v1_planet)
    deltaV2_arc = np.linalg.norm(v2_transfer - v2_planet)
    return deltaV1_arc, deltaV2_arc
    

def deltaV(planets, dep_date, tofs):
    """
    Calculates the Delta-V-s of a whole trajectory.
    ----------
    planets : planets that are used in the trajectory
    dep_date : First departure date (JD)
    tofs : List of tofs for each transfer arc

    Returns
    -------
    deltaV1_total : Total deltaV of departures
    deltaV2_total : Total deltaV of arrivals

    """
    mu = 1.327e20      # m^3/s^2
    planet_names = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    dep_dates = departure_dates(dep_date, tofs) # array with the departure dates of each transfer arc
    deltaV1_total = 0.0
    deltaV2_total = 0.0
    
    for i in range(len(tofs)): # number of arcs
        r1, v1, theta1 = state_vector(planet_names.index(planets[i]) + 1, julian_century(dep_dates[i]))
        r2, v2, theta2 = state_vector(planet_names.index(planets[i+1]) + 1, julian_century(dep_dates[i] + tofs[i]))
        #v1_t, v2_t = Lambert_Bate_1971_Z_BI_FG_SIMPLE(r1, r2, tofs[i]*24*3600, mu, 0, 1E-6)
        v1_t, v2_t, flag, iter_count = lambert_izzo_2015_x_hh_rt_norel(r1, r2, tofs[i]*24*3600, mu, 0, 0, 0, 1E-6)
        if np.isnan(v1_t).any() or np.isnan(v2_t).any(): # Assign a big value to "nan"
            v1_t = [1E99, 1E99, 1E99]
            v2_t = [1E99, 1E99, 1E99]
        deltaV1_arc, deltaV2_arc = deltaV_arc(v1, v2, v1_t, v2_t)
        deltaV1_total += deltaV1_arc
        deltaV2_total += deltaV2_arc
    return deltaV1_total, deltaV2_total
    
    
def MGA3_PGA2(planets, dep_date, tofs):
    mu = 1.327e20      # m^3/s^2
    """
    This function calculates the velocity values for each transfer 
    
    Parameters
    ----------
    planets : Planets that will be in the trajectory 
    (departure, flyby-s and arrrival)
    dep_date : Initial departure date
    tofs : Array with time of flights for each sub-transfer

    Returns
    -------
    v1_t_array : Array with all the departure velocities for each transfer 
    v2_t_array : Array with all the arrival velocities for each transfer 
    """
    planet_names = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
    r_planets = []
    v1_t_array = []
    v2_t_array = []
    dep_dates = departure_dates(dep_date, tofs)

    for i in range(len(planets)):
        JC = julian_century(dep_dates[0])
        if i != 0:
            for j in range(i):
                JC += julian_century(tofs[j])
        r, v, theta = state_vector(planet_names.index(planets[i]), JC)
        r_planets.append(r)   
        # para cada trayectoria hay que calcular las v_transfer-s
    for j in range(len(planets)-1): # para cada arco
        #v1_transfer, v2_transfer = Lambert_Bate_1971_Z_BI_FG_SIMPLE(r_planets[j-2], r_planets[j-1], tofs[j-1]*24*3600, mu, 0, 1E-6)
        v1_transfer, v2_transfer, flag, iter_count = lambert_izzo_2015_x_hh_rt_norel(r_planets[j-2], r_planets[j-1], tofs[j-1]*24*3600, mu, 0, 0, 0, 1E-6)
        if np.isnan(v1_transfer).any() or np.isnan(v2_transfer).any():
            v1_t_array.append([1E99, 1E99, 1E99])
            v2_t_array.append([1E99, 1E99, 1E99])
        else:
            v1_t_array.append(v1_transfer)
            v2_t_array.append(v2_transfer)
    return v1_t_array, v2_t_array

# -----------------------------------------------------------------------------
def UPC_ITDO24Q2_MGAPGA_AGA(planets, jd2k0_days, tofs_days):
    """
    UPC_ITDO24Q2_MGAPGA_AGA

    Description:
      Implements a simplified genetic algorithm (GA) optimiser for interplanetary
      trajectories with multi-gravity assists (MGA). The algorithm optimises the
      departure date and time-of-flight (TOF) segments for a specified sequence
      of planets using elitism, mutation, crossover (reproduction), and random
      newcomers.

    Usage:
      UPC_ITDO24Q2_MGAPGA_AGA()
    """

    # Define the sequence of planets for the gravity assist sequence
    #planets = ['', '', '', ...]

    # Scenario boundaries
    #jd2k0_days = [ , ]  # Departure dates (in days) relative to J2000
    #tofs_days = [ , ]   # TOF boundaries for each trajectory leg in days
    n_tofs = len(planets) - 1  # Number of flybys equals number of planets minus one
    # Define boundaries for departure date and TOF segments.
    # 'jd2k0' is a two-element list [min, max] and 'tofs' is a list of [min, max] pairs for each leg.
    boundaries = {
        'jd2k0': jd2k0_days,
        'tofs': [tofs_days for _ in range(n_tofs)]
    }

    # GA configuration parameters
    mut_dx = 0.1   	# Mutation perturbation factor (fraction of the parameter bounds)
    max_gen = 10  	# Maximum number of generations/iterations
    pop_size = 50 	# Total number of individuals in the population
    ne = 3       	# Number of elite individuals preserved without change
    nm = 3       	# Number of mutant individuals per generation
    nn = 5       	# Number of newcomers (random individuals) per generation
    na = 5       	# Number of best individuals from which parents are selected

    # Run the GA optimiser
    best_ind, best_fit = aga_simple(planets, boundaries, mut_dx, max_gen, pop_size, ne, nm, nn, na)

    # Format the time-of-flight values for display (each value rounded to 1 decimal)
    tofs_str = " ".join("{:.1f}".format(val) for val in best_ind['tofs'])
    print("jd2k0 = {:.1f}, tofs = [{}], fitness = {:.2f}".format(best_ind['jd2k0'], tofs_str, best_fit))
    
    return best_ind['jd2k0'], tofs_str, best_fit

# -----------------------------------------------------------------------------
def aga_simple(planets, bounds, mut_dx, max_gen, pop_size, ne, nm, nn, na):
    """
    aga_simple

    Description:
      Evolves a population of trajectory candidates using a genetic algorithm.
      The process incorporates elitism, mutation, crossover (reproduction), and
      random newcomers to improve the fitness of candidate solutions.

    Inputs:
      planets - List of planets (e.g., ['Earth', 'Jupiter', 'Saturn']).
      bounds  - Dictionary with keys:
                  'jd2k0': [min, max] departure date boundaries (in days from J2000)
                  'tofs':   List of [min, max] boundaries for each time-of-flight segment.
      mut_dx  - Mutation scaling factor (fraction of the parameter range).
      max_gen - Maximum number of generations (iterations).
      pop_size- Total number of individuals in the population.
      ne      - Number of elite individuals to preserve.
      nm      - Number of mutants generated per generation.
      nn      - Number of newcomers (random individuals) per generation.
      na      - Number of top individuals from which parents are selected for reproduction.

    Outputs:
      best_ind - Dictionary representing the best individual with keys:
                  'jd2k0': Departure date.
                  'tofs' : Time-of-flight segments (as a numpy array) 
      best_fit - Fitness (cost) value of the best individual (lower is better).
    """
    # Number of descendants to generate via reproduction (crossover)
    nd = pop_size - ne - nm - nn

    # Create initial population as a list of individuals (each a dict with keys 'jd2k0' and 'tofs')
    population = [
		ranfun(bounds) 
		for _ in range(pop_size)
	]

    # Main GA loop over generations
    for gen in range(max_gen):
        
		# Evaluate fitness for each individual (lower fitness is better)
        fitness = np.array([
			fitfun(planets, ind) 
			for ind in population
		])

        # Sort population by fitness in ascending order
        sorted_indices = np.argsort(fitness)
        population = [
			population[i] 
			for i in sorted_indices
		]
        fitness = fitness[sorted_indices]

        # Build the next generation population list
        next_population = []

        # --- Elitism: retain the best 'ne' individuals ---
        for i in range(ne):
            next_population.append(population[i])

        # --- Mutation: create 'nm' mutants from the next individuals ---
        for i in range(nm):
            # Note: using the (ne + i)-th individual for mutation
            mutant = mutfun(population[ne + i], bounds, mut_dx)
            next_population.append(mutant)

        # --- Reproduction: create 'nd' descendants via crossover ---
        for i in range(nd):
            # Randomly choose two parents among the top 'na' individuals
            parentA = population[np.random.randint(0, na)]
            parentB = population[np.random.randint(0, na)]
            descendant = repfun(parentA, parentB)
            next_population.append(descendant)

        # --- Newcomers: add 'nn' new random individuals ---
        for i in range(nn):
            newcomer = ranfun(bounds)
            next_population.append(newcomer)

        # Update the population for the next generation
        population = next_population

    # After the final generation, re-evaluate fitness to obtain the best individual.
    final_fitness = np.array([
		fitfun(planets, ind) 
		for ind in population
	])
    best_idx = np.nanargmin(final_fitness)
    best_ind = population[best_idx]
    best_fit = final_fitness[best_idx]
    return best_ind, best_fit


# -----------------------------------------------------------------------------
def ranfun(b):
    """
    ranfun

    Description:
      Generates a random individual (trajectory candidate) within the specified
      boundaries for departure date and time-of-flight segments.

    Input:
+            'jd2k0': [min, max] departure date boundaries (days from J2000)
            'tofs' : List of [min, max] boundaries for each time-of-flight segment.

    Output:
      A dictionary representing an individual with:
            'jd2k0': Random departure date within bounds.
            'tofs' : Numpy array of random time-of-flight values for each leg.
    """
    # Random departure date within bounds
    jd_min, jd_max = b['jd2k0']
    jd_range = jd_max - jd_min
    jd2k0 = jd_min + jd_range * np.random.rand()
    # Generate random time-of-flight values for each leg
    n_tofs = len(b['tofs'])
    tofs = np.array([
        b['tofs'][i][0] + (b['tofs'][i][1] - b['tofs'][i][0]) * np.random.rand()
        for i in range(n_tofs)
    ])

    return {'jd2k0': jd2k0, 'tofs': tofs}


# -----------------------------------------------------------------------------
def repfun(x1, x2):
    """
    repfun

    Description:
      Creates a new individual by averaging the parameters of two parent
      individuals (crossover operation).

    Inputs:
      x1 - First parent individual (dictionary with keys 'jd2k0' and 'tofs').
      x2 - Second parent individual.

    Output:
      A new individual (dictionary) whose parameters are the averages of the
      corresponding parameters of x1 and x2.
    """
    jd2k0 = (x1['jd2k0'] + x2['jd2k0']) / 2.0
    tofs = (x1['tofs'] + x2['tofs']) / 2.0
    return {'jd2k0': jd2k0, 'tofs': tofs}


# -----------------------------------------------------------------------------
def mutfun(x, b, dx):
    """
    mutfun

    Description:
      Mutates an individual by applying a small random perturbation to its
      departure date and time-of-flight segments. The perturbation is scaled
      to the parameter ranges, and the resulting values are clipped to remain
      within the specified boundaries.

    Inputs:
      x  - Individual to be mutated (dictionary with keys 'jd2k0' and 'tofs').
      b  - Dictionary with boundaries:
              'jd2k0': [min, max] departure date boundaries.
              'tofs' : List of [min, max] boundaries for each time-of-flight segment.
      dx - Mutation scaling factor (fraction of the parameter range).

    Output:
      A new mutated individual (dictionary) with updated parameters.
    """
    # Mutate departure date
    jd_min, jd_max = b['jd2k0']
    jd_range = jd_max - jd_min
    mutated_jd2k0 = x['jd2k0'] + dx * jd_range * (np.random.rand() - 0.5)
    # Ensure mutated departure date is within bounds
    mutated_jd2k0 = np.clip(mutated_jd2k0, jd_min, jd_max)

    # Mutate time-of-flight segments
    n_tofs = len(x['tofs'])
    mutated_tofs = np.empty_like(x['tofs'])
    for i in range(n_tofs):
        tof_min, tof_max = b['tofs'][i]
        tof_range = tof_max - tof_min
        mutated_val = x['tofs'][i] + dx * tof_range * (np.random.rand() - 0.5)
        # Clip the mutated value to remain within its boundaries
        mutated_tofs[i] = np.clip(mutated_val, tof_min, tof_max)

    return {'jd2k0': mutated_jd2k0, 'tofs': mutated_tofs}


# -----------------------------------------------------------------------------
def fitfun(planets, x):
    """
    fitfun

    Description:
      Computes the fitness (cost) of an individual trajectory candidate. The
      fitness is evaluated by simulating the MGA trajectory and calculating 
	  the sum of the departure and arrival delta-V magnitudes.

    Inputs:
      planets - List of planetary flybys.
      x       - Individual trajectory candidate (dictionary with keys 'jd2k0' and 'tofs').

    Output:
      dvt - Fitness (cost) value computed as the weighted sum of departure and
            arrival delta-V magnitudes. Lower values indicate a more optimal trajectory.
    """
    dep_date = x['jd2k0'] # this is a single dep date
    tofs = x['tofs']
    # Call the external function MGA3_PGA2 to compute the trajectory.
    #... = MGA3_PGA2(planets, dep_date, tofs)
    v1_t_array, v2_t_array = MGA3_PGA2(planets, dep_date, tofs)


    # Compute departure and arrival delta-V magnitudes using Euclidean norm.
    # v[0] and vd[0] correspond to the departure, v[-1] and va[-1] to the arrival.
    #x_dvd =   # Departure delta-V
    #x_dva =   # Arrival delta-V
    tofs_JC = []
    for JD in tofs: # pasa de JD a JC para usar la función deltaV
        tof_JC = julian_century(JD)
        tofs_JC.append(tof_JC)
        
    x_dvd, x_dva = deltaV(planets, dep_date, tofs)
    # Penalty factors (weights) for departure and arrival delta-V (both set to 1.0)
    fact_dvd = 1.0
    fact_dva = 1.0

    # Total fitness is the weighted sum of the departure and arrival delta-V
    dvt = fact_dvd * x_dvd + fact_dva * x_dva
    return dvt


# -----------------------------------------------------------------------------
#if __name__ == '__main__':
#    UPC_ITDO24Q2_MGAPGA_AGA(planets, jd2k0_days, tofs_days)