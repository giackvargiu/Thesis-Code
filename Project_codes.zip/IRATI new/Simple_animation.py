import numpy as np
import matplotlib.pyplot as plt
import matplotlib.animation as animation

# Enable interactive plotting in Spyder
%matplotlib qt  

# Create figure and axis
fig, ax = plt.subplots()
ax.set_xlim(0, 10)
ax.set_ylim(-1.5, 1.5)

# Create a red ball
ball, = ax.plot([], [], 'ro', markersize=10)  # 'ro' = red circle

# Generate x values
x_data = np.linspace(0, 10, 100)

# Update function
def update(frame):
    x = x_data[frame]
    y = np.sin(x)  # Movement along a sine wave
    ball.set_data(x, y)
    return ball,

# Create animation
ani = animation.FuncAnimation(fig, update, frames=len(x_data), interval=50, blit=True)

plt.show()

