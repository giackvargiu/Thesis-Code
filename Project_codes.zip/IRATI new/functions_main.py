import numpy as np
import math
import matplotlib.pyplot as plt

def planet_OP(number):
    # [a, a_dot, e, e_dot, i, i_dot, Omega, Omega_dot, omega, omega_dot, L, L_dot]
    planets = {
        # Mercury
        1: [0.38709927, 0.00000037, 0.20563593, 0.00001906, 7.00497902, -0.00594749,
            48.33076593, -0.12534081, 77.45779628, 0.16047689, 252.25032350, 149472.67411175],
        # Venus
        2: [0.72333566, 0.00000390, 0.00677672, -0.00004107, 3.39467605, -0.00078890,
            76.67984255, -0.27769418, 131.60246718, 0.00268329, 181.97909950, 58517.81538729],
        # Earth
        3: [1.00000261, 0.00000562, 0.01671123, -0.00004391, -0.00001531, -0.01294668,
            0.0, 0.0, 102.93768193, 0.32327364, 100.46457166, 35999.37244981],
        # Mars
        4: [1.52371034, 0.0001847, 0.09339410, 0.00007882, 1.84969142, -0.00813131,
            49.55953891, -0.29257343, -23.94362959, 0.44441088, -4.55343205, 19140.30268499],
        # Jupiter
        5: [5.20288700, -0.00011607, 0.04838624, -0.00013253, 1.30439695, -0.00183714,
            100.47390909, 0.20469106, 14.72847983, 0.21252668, 34.39644501, 3034.74612775],
        # Saturn
        6: [9.53667594, -0.00125060, 0.05386179, -0.00050991, 2.48599187, 0.00193609,
            113.66242448, -0.28867794, 92.59887831, -0.41897216, 49.95424423, 1222.49362201],
        # Uranus
        7: [19.18916464, -0.00196176, 0.04725744, -0.00004397, 0.77263783, -0.00242939,
            74.01692503, 0.04240589, 170.95427630, 0.40805281, 313.23810451, 428.48202785],
        # Neptune
        8: [30.06992276, 0.00026291, 0.00859048, 0.00005105, 1.77004347, 0.00035372,
            131.78422574, -0.00508664, 44.96476227, -0.32241464, -55.12002969, 218.45945325]
    }
    return planets.get(number, None)

def to_julian(y, m, d, utch, utcm, utcs):
    if m <= 2:
        y -= 1
        m += 12
    UT = utch + (utcm / 60.0) + (utcs / 3600.0)
    JD = int(365.25 * y) + int(30.6001 * (m + 1)) + d + UT / 24 + 1720981.5
    JC = (JD - 2451545) / 36525
    return JD, JC

def propagation(E, E_dot, jul_cent):
    return E + E_dot * jul_cent
    

def plot_main(planets, asteroids, day, month, year, utch=0, utcm=0, utcs=0):
    # Diccionarios de nombres y colores para los planetas
    planet_names = {
        1: "Mercury",
        2: "Venus",
        3: "Earth",
        4: "Mars",
        5: "Jupiter",
        6: "Saturn",
        7: "Uranus",
        8: "Neptune"
    }
    colors = {
        1: "gray",
        2: "yellow",
        3: "blue",
        4: "red",
        5: "orange",
        6: "lightblue",
        7: "gold",
        8: "purple"
    }
    
    Au = 149597870700  # 1 AU en metros
    
    # Masas aproximadas de planetas (kg) y del Sol (kg)
    planet_masses = {
        1: 3.3011e23,  # Mercury
        2: 4.8675e24,  # Venus
        3: 5.972e24,   # Earth
        4: 6.4171e23,  # Mars
        5: 1.8982e27,  # Jupiter
        6: 5.6834e26,  # Saturn
        7: 8.6810e25,  # Uranus
        8: 1.02413e26  # Neptune
    }
    sun_mass = 1.989e30  # kg

    # Obtener JD y siglos julianos usando la función to_julian
    JD, JC = to_julian(year, month, day, utch, utcm, utcs)
    
    fig, ax = plt.subplots(figsize=(8, 8))
    
    # Dibujar el Sol en el origen
    ax.plot(0, 0, marker='*', color='yellow', markersize=12,
            markerfacecolor='none', linestyle='None', label='Sun')
    
    # Dibujar los asteroides (posición actual) sin alterar
    for i in sorted(asteroids.keys()):
        r_ast = asteroids[i]
        r_ast_AU = r_ast / Au
        ax.plot(r_ast_AU[0], r_ast_AU[1], 'o', color='white', markersize=0.5)
    
    # Para cada planeta, dibujar su órbita elíptica y su posición actual
    for i in sorted(planets.keys()):
        r_current = planets[i]  # Posición actual en metros
        color = colors[i]
        
        # Obtener los parámetros orbitales del planeta y propagarlos con JC
        op = planet_OP(i)
        a_prop = propagation(op[0], op[1], JC) * Au  # semieje mayor en metros
        e_prop = propagation(op[2], op[3], JC)
        # Propagar el argumento del perihelio y convertir a radianes
        omega_prop = np.mod(math.radians(propagation(op[8], op[9], JC)), 2 * math.pi)
        
        
        # Generar puntos de la órbita en el plano orbital (perihelio en el eje x)
        f_vals = np.linspace(0, 2 * math.pi, 360)
        # Ecuación de la órbita: r = a(1 - e²) / (1 + e*cos(f))
        r_vals = a_prop * (1 - e_prop**2) / (1 + e_prop * np.cos(f_vals))
        x_orb = r_vals * np.cos(f_vals)
        y_orb = r_vals * np.sin(f_vals)
        
        # Rotar la órbita según el argumento del perihelio
        x_orbita = x_orb * np.cos(omega_prop) - y_orb * np.sin(omega_prop)
        y_orbita = x_orb * np.sin(omega_prop) + y_orb * np.cos(omega_prop)
        
        # Convertir la órbita de metros a AU
        x_orbita_AU = x_orbita / Au
        y_orbita_AU = y_orbita / Au
        
        # Dibujar la órbita elíptica
        ax.plot(x_orbita_AU, y_orbita_AU, '--', color=color, alpha=0.6)
        
        # Dibujar la posición actual del planeta
        r_current_AU = r_current / Au
        ax.plot(r_current_AU[0], r_current_AU[1], 'o', color=color, label=planet_names[i])
        
        # Calcular y dibujar la SOI
        # Se utiliza la norma de la posición actual para aproximar el semieje en AU
        a_AU = np.linalg.norm(r_current) / Au
        m = planet_masses[i]
        r_SOI = a_AU * (m / sun_mass) ** (2/5)  # Radio de la SOI en AU
        # Escalar la SOI para una mejor visualización
        scale_factor = 100 if i <= 4 else 10
        r_SOI_scaled = r_SOI * scale_factor
        soi_circle = plt.Circle((r_current_AU[0], r_current_AU[1]), r_SOI_scaled,
                                color=color, fill=True, alpha=0.2)
        ax.add_patch(soi_circle)
    
    ax.set_aspect('equal', 'box')
    ax.set_xlabel('X [AU]')
    ax.set_ylabel('Y [AU]')
    
    # Determinar el título y los límites de los ejes según los planetas mostrados
    keys = set(planets.keys())
    if keys == {1, 2, 3, 4, 5}:
        title_prefix = "Inner Planets of the Solar System"
        ax.set_xlim(-5, 5)
        ax.set_ylim(-5, 5)
    elif keys == {5, 6, 7, 8}:
        title_prefix = "Outer Planets of the Solar System"
        ax.set_xlim(-35, 35)
        ax.set_ylim(-35, 35)
    else:
        title_prefix = "Solar System"
        ax.set_xlim(-35, 35)
        ax.set_ylim(-35, 35)
    
    ax.set_title(f'{title_prefix} on the {day}/{month}/{year}')
    ax.legend(loc='upper left', fontsize='small')
    plt.show()

    