#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed Apr 30 00:07:42 2025

@author: giacomovargiu
"""

# Main code for plotting the planets and asteroids of the Solar System
# Irati Cadenato & Giacomo Vargiu
# Interplanetary trajectory Design and Optimization 2024/2025

# %matplotlib qt
# %matplotlib inline

import numpy as np
import matplotlib.pyplot as plt
from functions_plan import to_julian, position, state_vector
from functions_ast import position_ast
from functions_transf import plot_transfer_2D, plot_transfer_3D
from ANGLE import turning_angle
from Gravity_Assist import compute_swingby_parameters
from Interplanetary_double import Trajectories_final_3D, Trajectories_final_2D
from Swingby_3D import plot_3D_flyby_trajectory_only
from functions_optimization import UPC_ITDO24Q2_MGAPGA_AGA, from_julian
from matplotlib.ticker import FuncFormatter


def julian_century(JD):
    JC = (JD - 2451545) / 36525
    return JC

# Insert the initial (departure) date here
Y1 = 1977
M1 = 9
D1 = 5
utch1 = 0.0
utcm1 = 0.0
utcs1 = 0.0
JD1, JC1 = to_julian(Y1, M1, D1, utch1, utcm1, utcs1)
JD1 = 2443767.399438
JC1 = julian_century(JD1)
print("JD1: ", JD1)
plt.style.use('dark_background')


# File path for the database of asteroids
file_path = "Databases/astorb_200.txt" 

planets = position(JC1)
asteroids = position_ast(JD1, file_path)

#plot_main(planets, asteroids, D1, M1, Y1)

# 2. Inner planets: Mercury (1), Venus (2), Earth (3), Mars (4), Jupiter (5)
inner_planets = {k: planets[k] for k in (1, 2, 3, 4, 5)}
#plot_main(inner_planets, asteroids, D1, M1, Y1)

# 3. Outer planets: Jupiter (5), Saturn (6), Uranus (7), Neptune (8)
outer_planets = {k: planets[k] for k in (5, 6, 7, 8)}
#plot_main(outer_planets, asteroids, D1, M1, Y1)

# =============================================================================
# Project II: Swinging By!
# =============================================================================

# Insert the final (arrival) date here
Y2 = 1979
M2 = 3
D2 = 5
utch2 = 0.0
utcm2 = 0.0
utcs2 = 0.0
JD2, JC2 = to_julian(Y2, M2, D2, utch2, utcm2, utcs2)
JD2 = 2443767.399438 + 520.0
JC2 = julian_century(JD2)
tof_days = (JD2 - JD1)*24*3600 # in s
mu = 1.327e20 # m^3/s^2
AU = 149597870700  # 1 AU en metros

# Mercury = 1, Venus = 2, Earth = 3, Mars = 4, Jupiter = 5, Saturn = 6, Uranus = 7, Neptune = 8
departure_planet = 3
arrival_planet = 5

plot_transfer_2D(JC1, JC2, departure_planet, arrival_planet, tof_days)

h_transfer, intersection_SOI_dep, intersection_SOI_arr, v_dep_transfer, v_arr_transfer, r_arr, r_dep, x_dep, y_dep, z_dep, x_arr, y_arr, z_arr, x_transfer_rot, y_transfer_rot, z_transfer_rot = plot_transfer_3D(JC1, JC2, departure_planet, arrival_planet, tof_days)

print(h_transfer)
print(intersection_SOI_dep)
print(intersection_SOI_arr)
print(v_dep_transfer)
print(v_arr_transfer)
print(r_arr)

# Insert the initial (departure) date here
Y3 = 1979
M3 = 3
D3 = 5
utch3 = 0.0
utcm3 = 0.0
utcs3 = 0.0
JD3, JC3 = to_julian(Y3, M3, D3, utch3, utcm3, utcs3)
JD3 = JD2
JC3 = JC2

plt.style.use('dark_background')

# File path for the database of asteroids
file_path = "Databases/astorb_200.txt" 


planets = position(JC3)
asteroids = position_ast(JD3, file_path)

#plot_main(planets, asteroids, D1, M1, Y1)

# 2. Inner planets: Mercury (1), Venus (2), Earth (3), Mars (4), Jupiter (5)
inner_planets = {k: planets[k] for k in (1, 2, 3, 4, 5)}
#plot_main(inner_planets, asteroids, D1, M1, Y1)

# 3. Outer planets: Jupiter (5), Saturn (6), Uranus (7), Neptune (8)
outer_planets = {k: planets[k] for k in (5, 6, 7, 8)}
#plot_main(outer_planets, asteroids, D1, M1, Y1)

#Insert the final (arrival) date here
Y4 = 1980
M4 = 11
D4 = 12
utch4 = 0.0
utcm4 = 0.0
utcs4 = 0.0
JD4, JC4 = to_julian(Y4, M4, D4, utch4, utcm4, utcs4)
JD4 = 2443767.399438 + 520.0 + 837.5
JC4 = julian_century(JD4)
tof_days = (JD4 - JD3)*24*3600 # in s
mu = 1.327e20 # m^3/s^2
AU = 149597870700  # 1 AU en metros

# Mercury = 1, Venus = 2, Earth = 3, Mars = 4, Jupiter = 5, Saturn = 6, Uranus = 7, Neptune = 8
departure_planet2 = 5
arrival_planet2 = 6

plot_transfer_2D(JC3, JC4, departure_planet2, arrival_planet2, tof_days)

h_transfer2, intersection_SOI_dep2, intersection_SOI_arr2, v_dep_transfer2, v_arr_transfer2, r_arr2, r_dep2, x_dep2, y_dep2, z_dep2, x_arr2, y_arr2, z_arr2, x_transfer_rot2, y_transfer_rot2, z_transfer_rot2 = plot_transfer_3D(JC3, JC4, departure_planet2, arrival_planet2, tof_days)

print(h_transfer2)
print(intersection_SOI_dep2)
print(intersection_SOI_arr2)
print(v_dep_transfer2)
print(v_arr_transfer2)
print(r_arr2)


#####################################################################################################

# PLANETOCENTRIC VELOCITY VECTOR 
planet_id = 5  # Jupiter
position_vec, velocity_vec, theta = state_vector(planet_id, JC2)

print(velocity_vec)

v_in = velocity_vec - v_arr_transfer
v_out = velocity_vec - v_dep_transfer2

turning_angle, deg = turning_angle(v_in, v_out)
print(f"Turning angle: {deg:.2f}°")

# VELOCITY NORM AT ARRIVAL AND DEPARTURE OF INTERMEDIATE PLANET

V1 = np.linalg.norm(v_arr_transfer)*1e-3
V2 = np.linalg.norm(v_dep_transfer2)*1e-3

print(V1)
print(V2)


# Constants
mu_planet = 1.26686534e8  
r_planet = 71492  # km (Jupiter's radius)
r_soi_planet = 48.2e6 # km (Jupiter's SOI)

r_periapsis, Delta_V, r_SOI, a1, a2 = compute_swingby_parameters(V1, V2, mu_planet, turning_angle, r_planet, r_soi_planet)
print(f"Periapsis Radius: {r_periapsis:.2f} km")
print(f"Required Delta V: {Delta_V:.2f} km/s")
plot_3D_flyby_trajectory_only(r_periapsis, a1, a2, v_arr_transfer, v_dep_transfer, r_SOI=None)

#####################################################################################################

# FULL TRAJECTORY
Trajectories_final_2D(r_dep, r_dep2, departure_planet, departure_planet2, r_arr, r_arr2, arrival_planet, arrival_planet2, x_dep, y_dep, x_dep2, y_dep2, x_arr, y_arr, x_arr2, y_arr2, x_transfer_rot, y_transfer_rot, x_transfer_rot2, y_transfer_rot2)
Trajectories_final_3D(r_dep, r_dep2, departure_planet, departure_planet2, r_arr, r_arr2, arrival_planet, arrival_planet2, x_dep, y_dep, z_dep, x_dep2, y_dep2, z_dep2, x_arr, y_arr, z_arr, x_arr2, y_arr2, z_arr2, x_transfer_rot, y_transfer_rot, z_transfer_rot, x_transfer_rot2, y_transfer_rot2, z_transfer_rot2)


planet_names = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
planets = ["Earth", "Jupiter", "Saturn"]
tof_days_minmax = [30.0, 30.0 * 12 * 3] # maximo 3 años para cada trajectory
jd2k0_days = [JD1 - 30.0 * 12, JD1 + 30.0 * 12 * 4] # minimum and maximum departure dates

# Scenario boundaries
#jd2k0_days is the boundaries [min, max] for departure dates (in days) relative to J2000
#tofs_days is the boundaries [min, max] for TOF for each trajectory leg in days

UPC_ITDO24Q2_MGAPGA_AGA(planets, jd2k0_days, tof_days_minmax)

# Número de ejecuciones
n_runs = 100

# Array para guardar los valores de jd2k0
jd2k0_values = np.zeros(n_runs)
tof_values = tof_values = np.zeros((n_runs, 2)) 
fitness_values = np.zeros(n_runs)

# Ejecutar la función varias veces y almacenar jd2k0
for i in range(n_runs):
    jd2k0, tofs, fitness = UPC_ITDO24Q2_MGAPGA_AGA(planets,
                                                   jd2k0_days,
                                                   tof_days_minmax)
    jd2k0_values[i] = jd2k0
    tof_list = [float(val) for val in tofs.split()]
    tof_values[i, :] = tof_list
    fitness_values[i] = fitness

# Calcular la media y el error absoluto frente a la referencia
mean_jd2k0 = np.mean(jd2k0_values)
ref_jd = 2443391.5
error = abs(mean_jd2k0 - ref_jd)

# Encontrar el mínimo fitness y su índice
min_fitness = np.min(fitness_values)
min_index = np.argmin(fitness_values)
min_jd2k0 = jd2k0_values[min_index]
min_tofs = tof_values[min_index]

# Convertir la fecha de salida a formato legible
min_year, min_month, min_day, _, _, _ = from_julian(min_jd2k0)

# Imprimir resultados
print("\n--- Best Trajectory ---")
print(f"Minimum Delta-V (fitness): {min_fitness:.2f} m/s")
print(f"Launch date (Julian): {min_jd2k0:.2f}")
print(f"Launch date (Gregorian): {min_year}-{min_month:02d}-{min_day:02d}")
print(f"Time of flight segments (days): {min_tofs}")

# Imprimir resultados numéricos
print(f"Mean jd2k0 over {n_runs} runs: {mean_jd2k0:.2f}")
print(f"Error vs reference {ref_jd}: {error:.2f}")



# Función para formatear un Julian Date a "YYYY-MM-DD"
def jd_to_ymd(x, pos):
    year, month, day, hour, minute, second = from_julian(x)
    return f"{year:04d}-{month:02d}-{day:02d}"

# --- GRÁFICO SCATTER SOBRE FONDO BLANCO ---
plt.style.use('default')
fig, ax = plt.subplots(figsize=(8, 5))
ax.set_facecolor('white')

# Scatter: eje X = iteración, eje Y = jd2k0
ax.scatter(range(n_runs), jd2k0_values, marker='o', label='Runs')

# Línea discontinua roja en la fecha de referencia
ax.axhline(ref_jd, linestyle='--', color='red',
           label=f'Ref {from_julian(ref_jd)[0]:04d}-{from_julian(ref_jd)[1]:02d}-{from_julian(ref_jd)[2]:02d}')

# Línea continua verde en la fecha media
ymd_mean = from_julian(mean_jd2k0)
ax.axhline(mean_jd2k0, linestyle='-', color='green',
           label=f'Mean {ymd_mean[0]:04d}-{ymd_mean[1]:02d}-{ymd_mean[2]:02d}')

# Aplicar el formateador de fechas al eje Y
ax.yaxis.set_major_formatter(FuncFormatter(jd_to_ymd))
plt.setp(ax.get_yticklabels(), rotation=45, ha='right')

ax.set_xlabel("Iteration")
ax.set_ylabel("Date")
ax.set_title("Evolution of jd2k0 over the runs")
ax.legend(loc='upper right')
plt.tight_layout()
plt.show()

## TOTAL DELTA_V MANEUVER FOR VOYAGER 1

# First maneuver is at departure to get into the first Lambert arc

planet_id = 3  #Earth
position_vector1, velocity_vector_departure_from_planet, theta_A = state_vector(planet_id, JC1)

Delta_V1_vec = velocity_vector_departure_from_planet - v_dep_transfer
Delta_V1 = np.linalg.norm(Delta_V1_vec)*1e-3

print(f"Required Delta V at departure from Earth: {Delta_V1:.2f} km/s")

# Second maneuver is at periapsis of Jupiter for PGA

Delta_V2 = Delta_V

print(f"Required Delta V at periapsis of Jupiter: {Delta_V2:.2f} km/s")

# Third maneuver is upon arrival to Saturn to get into orbit

planet_id = 6  #Saturn
position_vector2, velocity_vector_arrival_at_final_planet, theta_B = state_vector(planet_id, JC4)

Delta_V3_vec = velocity_vector_arrival_at_final_planet - v_arr_transfer2
Delta_V3 = np.linalg.norm(Delta_V3_vec)*1e-3

print(f"Required Delta V upon arrival at Saturn: {Delta_V3:.2f} km/s")

TOTAL_DELTA_V = Delta_V1 + Delta_V2 + Delta_V3

print(f"Total Required Delta V: {TOTAL_DELTA_V:.2f} km/s")

# 2443391.5



