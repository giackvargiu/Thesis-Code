# Main code for verification of subroutines for the planets case
# Irati Cadenato
# Interplanetary trajectory Design and Optimization 2024/2025

import unittest
import math
import numpy as np
from functions_plan import (to_julian, propagation, angular_momentum, 
                            mean_anomaly, true_anomaly, rotational_matrix, 
                            arg_per, kepler, kepler_der, newton_raphson,
                            state_vector, position)


def dummy_planet_OP(i):
    # Devuelve 12 parámetros orbitales fijos para testear:
    # [a, a_dot, e, e_dot, i, i_dot, Omega, Omega_dot, omega, omega_dot, L, L_dot]
    return [1.0, 0.0, 0.1, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0]
# Como state_vector y position utilizan planet_OP, sobreescribimos la función globalmente para los tests:
global planet_OP
planet_OP = dummy_planet_OP

# Planet verification #

class TestSubroutines(unittest.TestCase):
    def test_to_julian_midnight(self):
        # Para la fecha: 28 de febrero de 2025, a medianoche (UT 0:0:0)
        JD, JC = to_julian(2025, 2, 28, 0.0, 0.0, 0.0)
        # Cálculos: al tratarse de febrero (m<=2) la función ajusta el año y el mes:
        # Se espera que JD sea 2460734.5 (según el algoritmo implementado)
        self.assertAlmostEqual(JD, 2460734.5, places=1)
        # Y JC se calcula como (JD - 2451545) / 36525, lo que da aproximadamente 0.2518
        self.assertAlmostEqual(JC, (2460734.5 - 2451545) / 36525, places=4)
        
    def test_to_julian_noon(self):
        # Comprobar que al pasar la misma fecha pero a mediodía (UT 12:0:0)
        # el JD es 0.5 días mayor que al usar medianoche
        JD_mid, _ = to_julian(2025, 2, 28, 0.0, 0.0, 0.0)
        JD_noon, _ = to_julian(2025, 2, 28, 12.0, 0.0, 0.0)
        self.assertAlmostEqual(JD_noon, JD_mid + 0.5, places=1)
        
    def test_propagation(self):
        # Ejemplo: E=10, E_dot=0.5, jul_cent=100 → resultado esperado: 10 + 0.5*100 = 60
        E = 10.0
        E_dot = 0.5
        jul_cent = 100.0
        expected = 10.0 + 0.5 * 100.0
        result = propagation(E, E_dot, jul_cent)
        self.assertAlmostEqual(result, expected, places=6)
        
    def test_angular_momentum(self):
        # Ejemplo: mu=4, a=9, e=0.5 → resultado esperado: sqrt(4*9*(1-0.25)) = sqrt(27)
        mu = 4.0
        a = 9.0
        e = 0.5
        expected = math.sqrt(mu * a * (1 - e**2))
        result = angular_momentum(mu, a, e)
        self.assertAlmostEqual(result, expected, places=6)
        
    def test_mean_anomaly(self):
        # Ejemplo: omega_prop=30, L_prop=60 → resultado esperado: 60 - 30 = 30
        omega_prop = 30.0
        L_prop = 60.0
        expected = L_prop - omega_prop
        result = mean_anomaly(omega_prop, L_prop)
        self.assertAlmostEqual(result, expected, places=6)
        
    def test_true_anomaly_circular(self):
        # Para órbita circular (e=0), la anomalía verdadera debe ser igual a la exéntrica.
        e = 0.0
        E = 1.0  # radianes
        expected = E
        result = true_anomaly(e, E)
        self.assertAlmostEqual(result, expected, places=6)
        
    def test_true_anomaly_no_circular(self):
        # Con e ≠ 0, se verifica que la función realice el cálculo correcto.
        e = 0.5
        E = 1.0  # radianes
        expected = 2.0 * math.atan(math.tan(E / 2.0) * math.sqrt((1 + e) / (1 - e)))
        result = true_anomaly(e, E)
        self.assertAlmostEqual(result, expected, places=6)
        
    def test_rotational_matrix_identity(self):
        # Cuando Omega, omega e inclinación son 0, la matriz de rotación debe ser la identidad.
        Omega = 0.0
        omega = 0.0
        inclination = 0.0
        expected = np.identity(3)
        result = rotational_matrix(Omega, omega, inclination)
        np.testing.assert_array_almost_equal(result, expected, decimal=6)
        
    def test_arg_per(self):
        # Ejemplo: omega_prop=50, Omega_prop=30 → resultado esperado: 20
        omega_prop = 50.0
        Omega_prop = 30.0
        expected = 20.0
        result = arg_per(omega_prop, Omega_prop)
        self.assertAlmostEqual(result, expected, places=6)
        
    def test_kepler(self):
        # Si e=0, la ecuación de Kepler se reduce a: E - M = 0, es decir E = M.
        M = 1.0
        E = 1.0
        e = 0.0
        result = kepler(M, E, e)
        self.assertAlmostEqual(result, 0.0, places=6)
        
        # Con e distinto de cero
        M = 0.5
        E = 0.7
        e = 0.1
        expected = E - e * np.sin(E) - M
        result = kepler(M, E, e)
        self.assertAlmostEqual(result, expected, places=6)
    
    def test_kepler_der(self):
        # Para e=0, la derivada es siempre 1
        E = 1.0
        e = 0.0
        result = kepler_der(E, e)
        self.assertAlmostEqual(result, 1.0, places=6)
        
        # Con e distinto de cero
        E = 0.7
        e = 0.1
        expected = 1.0 - e * np.cos(E)
        result = kepler_der(E, e)
        self.assertAlmostEqual(result, expected, places=6)
    
    def test_newton_raphson(self):
        # Caso circular: e = 0 → E debe ser igual a M
        M = 1.0
        e = 0.0
        N = 100
        eps = 1e-12
        result = newton_raphson(M, e, N, eps)
        self.assertAlmostEqual(result, M, places=6)
        
        # Caso con excentricidad pequeña:
        M = 0.5
        e = 0.1
        result = newton_raphson(M, e, N, eps)
        # Comprobamos que la solución satisface la ecuación de Kepler:
        self.assertAlmostEqual(kepler(M, result, e), 0.0, places=6)
    
    def test_state_vector(self):
        # Utilizando dummy_planet_OP y valores sencillos.
        jul_cent = 0.1  # Valor arbitrario para la propagación
        r, v, theta = state_vector(dummy_planet_OP(1), jul_cent)
        # Comprobamos que r y v sean arrays de 3 elementos
        self.assertEqual(r.shape, (3,))
        self.assertEqual(v.shape, (3,))
        # theta debe ser un número (float)
        self.assertIsInstance(theta, float)
        
    def test_position(self):
        # Para un valor arbitrario de julian_century, se deben calcular 8 posiciones.
        julian_century = 0.1
        planets_dict = position(julian_century)
        self.assertEqual(len(planets_dict), 8)
        for key in range(1, 9):
            self.assertIn(key, planets_dict)
            # Cada posición debe ser un array de 3 elementos
            self.assertEqual(planets_dict[key].shape, (3,))


if __name__ == '__main__':
    unittest.main()
