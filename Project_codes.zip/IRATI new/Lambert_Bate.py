import numpy as np

def Lambert_Bate_1971_Z_BI_FG_SIMPLE(r1, r2, tof, mu, lw, tol):
    """
    Lambert_Bate_1971_Z_BI_FG_SIMPLE Solves Lambert's problem
        Algorithm: Bate, Mueller & White [1]
        Parameter: universal variable z [1]
        Solver: Bisection [2]
        Velocity: Gauss f, g [1]

    Inputs:
        r1: position vector of departure point (array-like)
        r2: position vector of arrival point (array-like)
        tof: time of flight
        mu: standard gravitational parameter of the central body
        lw: transfer type
            0: type I (short-way) transfer
            1: type II (long-way) transfer
        tol: iteration tolerance: tol = abs(t - tof)

    Outputs:
        v1: final velocity at departure point (after the manoeuvre)
        v2: initial velocity at arrival point (before the manoeuvre)

    Example:
        v1, v2 = Lambert_Bate_1971_Z_BI_FG_SIMPLE(
                    np.array([1,0,0]), np.array([0,2,0]), np.pi, 1, 0, 1E-6 )

    References:
        [1] Bate, Roger R., D.D. Mueller, and J.E. White
            Fundamentals of Astrodynamics, Section 5.3
            New Dover Publications, New York, 1971
        [2] Vallado, David A.
            Fundamentals of Astrodynamics and Applications, Section 6.7
            The McGraw-Hill Companies, Inc., New York, 1997
        [3] Rodney L. Anderson
            Solution to the Lambert Problem using Universal Variables

    David de la Torre
    August 2015
    """

    # Internal parameters
    ni = int(1E2)  # Maximum number of iterations
    # Preallocate v1 and v2 (they will be overwritten later)
    v1 = np.full(3, np.nan)
    v2 = np.full(3, np.nan)

    # Auxiliary magnitudes
    r1 = np.array(r1, dtype=float)
    r2 = np.array(r2, dtype=float)
    r1n = np.linalg.norm(r1)  # Norm of r1
    r2n = np.linalg.norm(r2)  # Norm of r2
    mutt0 = np.sqrt(mu) * tof  # Mu times TOF

    # Compute geometrical parameters
    cos_phi = np.dot(r1, r2) / (r1n * r2n)  # Cosine of transfer angle (phi)
    A = np.sqrt(r1n * r2n * (1 + cos_phi))  # [1] Eq 5.3-27
    if lw:
        A = -A  # Type II (long-way) transfer

    # Initialize iteration parameters
    z_low = -4.0 * np.pi  # Bisection lower limit [2]
    z_up = 4.0 * np.pi ** 2  # Bisection upper limit [2]
    z = (z_up + z_low) / 2.0  # Initial guess

    # Solver: Bisection method to solve for z
    for i in range(ni):
        # Compute Stumpff coefficients
        # [1] Karl Stumpff (1895-1970)
        if z > 1E-8:  # Elliptic case
            y_temp = np.sqrt(z)
            C = (1.0 - np.cos(y_temp)) / z
            S = (y_temp - np.sin(y_temp)) / (z * y_temp)
        elif z < -1E-8:  # Hyperbolic case
            y_temp = np.sqrt(-z)
            C = (1.0 - np.cosh(y_temp)) / z
            S = (np.sinh(y_temp) - y_temp) / (-z * y_temp)
        else:  # Parabolic case
            C = 0.5
            S = 1.0 / 6.0
        
        # Calculate area sector ratio y
        # [1] Eq 5.3-9
        y = r1n + r2n - A * (1 - z * S) / np.sqrt(C)
        #if y < 0:
            #print(f"[{i}] Skipping iteration: y < 0")
            #z = (z_low + z) / 2 if lw else (z + z_up) / 2
        #continue
        # Calculate universal variable x
        # [1] Eq 5.3-10
        x = np.sqrt(y / C)

        # Calculate t (mu * tof)
        # [1] Eq 5.3-12
        mutt = x ** 3 * S + A * np.sqrt(y)

        # Check convergence
        if np.abs(mutt - mutt0) < tol:
            break

        # If maximum iterations exceeded, return current values
        if i >= ni - 1:
            return v1, v2

        # Update bisection upper and lower values [3]
        if mutt <= mutt0:
            z_low = z
        else:
            z_up = z

        # Recalculate iteration parameter via bisection method [3]
        z = 0.5 * (z_up + z_low)

    # Post-process: Compute Gauss f, g, and g_dot functions
    f = 1 - y / r1n  # [1] Eq 5.3-13
    g = A * np.sqrt(y / mu)  # [1] Eq 5.3-14
    gd = 1 - y / r2n  # [1] Eq 5.3-15

    # Compute velocity vectors
    v1 = (r2 - f * r1) / g  # [1] Eq 5.3-16
    v2 = (gd * r2 - r1) / g  # [1] Eq 5.3-17

    return v1, v2