import numpy as np
import matplotlib.pyplot as plt
from datetime import datetime, timedelta

# Import your functions
from functions_plan import to_julian, position, state_vector
from lambert_izzo_2015_x_hh_rt_norel import lambert_izzo_2015_x_hh_rt_norel

def main_pcp(Planet_index, n, DeltaT_min, DeltaT_Max):
    # Constants
    Planet_index_earth = 3
    mu_sun = 1.327e20  # Gravitational parameter of the Sun, m^3/s^2
    AU = 1.495978707e11  # Astronomical Unit in meters

    # Departure dates
    t1 = datetime.strptime('2020-01-01', '%Y-%m-%d')
    t2 = datetime.strptime('2025-01-01', '%Y-%m-%d')

    launch_dates = np.linspace(t1.timestamp(), t2.timestamp(), n)
    launch_dates = [datetime.fromtimestamp(ts) for ts in launch_dates]

    deltaT_days = np.linspace(DeltaT_min, DeltaT_Max, n)

    # Initialize Delta-V matrix
    Delta_V_matrix = np.zeros((n, n))

    for i in range(n):
        for j in range(n):
            launch_date = launch_dates[i]
            delta_t_days = deltaT_days[j]
            arrival_date = launch_date + timedelta(days=delta_t_days)

            print(f'Launch Date: {launch_date.strftime("%Y-%m-%d")})
            print(f'Arrival Date: {arrival_date.strftime("%Y-%m-%d")})

            # Julian dates
            JD_launch, JC_launch = to_julian(launch_date.year, launch_date.month, launch_date.day, 0, 0, 0)
            JD_arrival, JC_arrival = to_julian(arrival_date.year, arrival_date.month, arrival_date.day, 0, 0, 0)

            # Planetary positions and velocities
            r_earth = position(JC_launch)[Planet_index_earth - 1]
            r_planet = position(JC_arrival)[Planet_index - 1]

            v_earth = state_vector(JC_launch)[Planet_index_earth - 1]
            v_planet = state_vector(JC_arrival)[Planet_index - 1]

            # Solve Lambert's problem
            Delta_t_sec = delta_t_days * 24 * 3600
            V1, V2, _ = lambert_izzo_2015_x_hh_rt_norel(r_earth, r_planet, Delta_t_sec, mu_sun)

            # Compute Delta V
            Delta_V1 = np.linalg.norm(V1 - v_earth)
            Delta_V2 = np.linalg.norm(v_planet - V2)
            Delta_V = Delta_V1 + Delta_V2

            print(f'Delta V1: {Delta_V1:.2f} m/s')
            print(f'Delta V2: {Delta_V2:.2f} m/s')
            print(f'Total Delta V: {Delta_V:.2f} m/s')

            # Store results
            Delta_V_matrix[i, j] = Delta_V

    # Limit the values in Delta_V_matrix to 50 km/s
    Delta_V_matrix_limited = np.minimum(Delta_V_matrix * 1e-3, 50)  # Convert to km/s

    return Delta_V_matrix_limited, launch_dates, deltaT_days

def plot_delta_v(Delta_V_matrix_limited, launch_dates, deltaT_days):
    plt.figure(figsize=(10, 8))
    plt.imshow(Delta_V_matrix_limited, origin='lower', extent=[deltaT_days[0], deltaT_days[-1], 
                                                               launch_dates[0].toordinal(), launch_dates[-1].toordinal()],
               aspect='auto', cmap='plasma')
    plt.colorbar(label='Total Delta-V (km/s)')
    plt.xlabel('Time of Flight (days)')
    plt.ylabel('Launch Date')

    # Format y-axis as dates
    yticks = np.linspace(launch_dates[0].toordinal(), launch_dates[-1].toordinal(), 10)
    ytick_labels = [datetime.fromordinal(int(day)).strftime('%Y-%m-%d') for day in yticks]
    plt.yticks(yticks, ytick_labels, rotation=45)

    plt.title('Porkchop Plot (Delta-V Map)')
    plt.tight_layout()
    plt.show()

# Example usage (assuming all helpers are present):
# Delta_V_matrix_limited, launch_dates, deltaT_days = main_pcp(4, 10, 100, 300)
# plot_delta_v(Delta_V_matrix_limited, launch_dates, deltaT_days)
