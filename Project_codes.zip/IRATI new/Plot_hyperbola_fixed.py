#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Wed May 21 17:44:01 2025

@author: giacomovargiu
"""


#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Plots hyperbolic flyby trajectories using accurate orbital equations.
"""

import numpy as np
import matplotlib.pyplot as plt

def plot_hyperbolic_trajectory(r_pi, a1, a2, r_SOI):
    """
    Plot inbound and outbound hyperbolic trajectories.
    """
    if a1 == 0 or a2 == 0:
        raise ValueError("Semi-major axis cannot be zero.")

    n = 500
    e1 = r_pi / a1 + 1
    e2 = r_pi / a2 + 1
    theta = np.linspace(-3, 3, n)  # safer than full ±π for cosh()

    def hyperbolic_coords(a, e, theta):
        r = np.abs(a) * (e * np.cosh(theta) - 1)
        x = r * np.cosh(theta)
        y = r * np.sinh(theta)
        return x, y

    x1, y1 = hyperbolic_coords(a1, e1, theta)
    x2, y2 = hyperbolic_coords(a2, e2, theta)
    y2 = -y2  # mirror outbound

    plt.figure(figsize=(8, 8))
    plt.plot(x1, y1, label="Inbound", color='blue')
    plt.plot(x2, y2, label="Outbound", color='red')
    plt.scatter([0], [0], color='green', marker='x', label="Planet")
    plt.scatter([r_pi], [0], color='orange', label="Periapsis")
    plt.axhline(0, color='k', linestyle='--', linewidth=0.5)
    plt.axvline(0, color='k', linestyle='--', linewidth=0.5)
    plt.xlabel("Distance (km)")
    plt.ylabel("Distance (km)")
    plt.title("Hyperbolic Flyby Trajectory")
    plt.legend()
    plt.axis('equal')
    plt.grid()
    plt.xlim(-r_SOI/7, r_SOI/7)
    plt.ylim(-r_SOI/7, r_SOI/7)
    plt.show()
