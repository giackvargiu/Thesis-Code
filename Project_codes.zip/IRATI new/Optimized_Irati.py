# Main code for plotting the planets and asteroids of the Solar System
# Irati Cadenato & Giacomo Vargiu
# Interplanetary trajectory Design and Optimization 2024/2025

import numpy as np
import matplotlib.pyplot as plt
from functions_plan import to_julian, position, state_vector, planet_OP
from functions_ast import position_ast
from functions_main import plot_main
from functions_transf import plot_transfer_2D, plot_transfer_3D
from ANGLE import angle_from_coord, turning_angle
from Gravity_Assist import compute_swingby_parameters
from Interplanetary_double import Trajectories_final_3D, Trajectories_final_2D
from functions_optimization import UPC_ITDO24Q2_MGAPGA_AGA

# Insert the initial (departure) date here
Y1 = 1977
M1 = 9
D1 = 5
utch1 = 0.0
utcm1 = 0.0
utcs1 = 0.0
JD1, JC1 = to_julian(Y1, M1, D1, utch1, utcm1, utcs1)

plt.style.use('dark_background')

# File path for the database of asteroids
file_path = "Databases/astorb_200.txt" 

planets = position(JC1)
asteroids = position_ast(JD1, file_path)

plot_main(planets, asteroids, D1, M1, Y1)

# 2. Inner planets: Mercury (1), Venus (2), Earth (3), Mars (4), Jupiter (5)
inner_planets = {k: planets[k] for k in (1, 2, 3, 4, 5)}
plot_main(inner_planets, asteroids, D1, M1, Y1)

# 3. Outer planets: Jupiter (5), Saturn (6), Uranus (7), Neptune (8)
outer_planets = {k: planets[k] for k in (5, 6, 7, 8)}
plot_main(outer_planets, asteroids, D1, M1, Y1)

# =============================================================================
# Project II: Swinging By!
# =============================================================================

# Insert the final (arrival) date here
Y2 = 1979
M2 = 3
D2 = 5
utch2 = 0.0
utcm2 = 0.0
utcs2 = 0.0
JD2, JC2 = to_julian(Y2, M2, D2, utch2, utcm2, utcs2)
tof_days = (JD2 - JD1)*24*3600 # in s
mu = 1.327e20 # m^3/s^2
AU = 149597870700  # 1 AU en metros

# Mercury = 1, Venus = 2, Earth = 3, Mars = 4, Jupiter = 5, Saturn = 6, Uranus = 7, Neptune = 8
departure_planet = 3
arrival_planet = 5

plot_transfer_2D(JC1, JC2, departure_planet, arrival_planet, tof_days)

h_transfer, intersection_SOI_dep, intersection_SOI_arr, v_dep_transfer, v_arr_transfer, r_arr, r_dep, x_dep, y_dep, z_dep, x_arr, y_arr, z_arr, x_transfer_rot, y_transfer_rot, z_transfer_rot = plot_transfer_3D(JC1, JC2, departure_planet, arrival_planet, tof_days)

# Insert the initial (departure) date here
Y3 = 1980
M3 = 11
D3 = 12
utch3 = 0.0
utcm3 = 0.0
utcs3 = 0.0
JD3, JC3 = to_julian(Y3, M3, D3, utch3, utcm3, utcs3)

plt.style.use('dark_background')

# File path for the database of asteroids
file_path = "Databases/astorb_200.txt" 

planets = position(JC3)
asteroids = position_ast(JD3, file_path)

#plot_main(planets, asteroids, D1, M1, Y1)

# 2. Inner planets: Mercury (1), Venus (2), Earth (3), Mars (4), Jupiter (5)
inner_planets = {k: planets[k] for k in (1, 2, 3, 4, 5)}
#plot_main(inner_planets, asteroids, D1, M1, Y1)

# 3. Outer planets: Jupiter (5), Saturn (6), Uranus (7), Neptune (8)
outer_planets = {k: planets[k] for k in (5, 6, 7, 8)}
#plot_main(outer_planets, asteroids, D1, M1, Y1)
# Insert the final (arrival) date here
Y4 = 1980
M4 = 11
D4 = 12
utch4 = 0.0
utcm4 = 0.0
utcs4 = 0.0
JD4, JC4 = to_julian(Y4, M4, D4, utch4, utcm4, utcs4)
tof_days = (JD4 - JD3)*24*3600 # in s
mu = 1.327e20 # m^3/s^2
AU = 149597870700  # 1 AU en metros

# Mercury = 1, Venus = 2, Earth = 3, Mars = 4, Jupiter = 5, Saturn = 6, Uranus = 7, Neptune = 8
departure_planet2 = 5
arrival_planet2 = 6

plot_transfer_2D(JC3, JC4, departure_planet2, arrival_planet2, tof_days)

h_transfer2, intersection_SOI_dep2, intersection_SOI_arr2, v_dep_transfer2, v_arr_transfer2, r_arr2, r_dep2, x_dep2, y_dep2, z_dep2, x_arr2, y_arr2, z_arr2, x_transfer_rot2, y_transfer_rot2, z_transfer_rot2 = plot_transfer_3D(JC3, JC4, departure_planet2, arrival_planet2, tof_days)

#####################################################################################################

# PLANETOCENTRIC VELOCITY VECTOR 
planet_id = 5  # Jupiter
position_vec, velocity_vec, theta = state_vector(planet_id, JC2)

v_in = velocity_vec - v_arr_transfer
v_out = velocity_vec - v_dep_transfer2

turning_angle, deg = turning_angle(v_in, v_out)

# VELOCITY NORM AT ARRIVAL AND DEPARTURE OF INTERMEDIATE PLANET

V1 = np.linalg.norm(v_arr_transfer)*1e-3
V2 = np.linalg.norm(v_dep_transfer2)*1e-3

# Constants
mu_planet = 1.26686534e8  
r_planet = 71492  # km (Jupiter's radius)
r_soi_planet = 48.2e6 # km (Jupiter's SOI)

r_periapsis, Delta_V = compute_swingby_parameters(V1, V2, mu_planet, turning_angle, r_planet, r_soi_planet)

#####################################################################################################

# FULL TRAJECTORY
Trajectories_final_2D(r_dep, r_dep2, departure_planet, departure_planet2, r_arr, r_arr2, arrival_planet, arrival_planet2, x_dep, y_dep, x_dep2, y_dep2, x_arr, y_arr, x_arr2, y_arr2, x_transfer_rot, y_transfer_rot, x_transfer_rot2, y_transfer_rot2)
Trajectories_final_3D(r_dep, r_dep2, departure_planet, departure_planet2, r_arr, r_arr2, arrival_planet, arrival_planet2, x_dep, y_dep, z_dep, x_dep2, y_dep2, z_dep2, x_arr, y_arr, z_arr, x_arr2, y_arr2, z_arr2, x_transfer_rot, y_transfer_rot, z_transfer_rot, x_transfer_rot2, y_transfer_rot2, z_transfer_rot2)


# =============================================================================
# Project III: The Voyage (Optimization)
# =============================================================================

planet_names = ["Mercury", "Venus", "Earth", "Mars", "Jupiter", "Saturn", "Uranus", "Neptune"]
planets = [planet_names[departure_planet-1], planet_names[arrival_planet-1]]
tof_days_minmax = [30.0, tof_days]
# jd2k0_days = []
# jd2k0_days_aux1 = julian_day(JC1)
# jd2k0_days_aux2 = julian_day(JC2)
# jd2k0_days.append(jd2k0_days_aux1)
# jd2k0_days.append(jd2k0_days_aux2)
jd2k0_days = [JD1, JD1 + 30.0 * 24] # minimum 1 month maximum 2 years for the departure date from today

# Scenario boundaries
#jd2k0_days is the boundaries [min, max] for departure dates (in days) relative to J2000
#tofs_days is the boundaries [min, max] for TOF for each trajectory leg in days

UPC_ITDO24Q2_MGAPGA_AGA(planets, jd2k0_days, tof_days_minmax)

