#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 22 16:54:28 2025

@author: giacomovargiu
"""

import numpy as np
import matplotlib.pyplot as plt
from functions_plan import to_julian, state_vector
from functions_transf import plot_transfer_2D, plot_transfer_3D
from ANGLE import turning_angle
from Gravity_Assist import compute_swingby_parameters
from Interplanetary_triple import Trajectories_triple_3D, Trajectories_triple_2D
from Swingby_3D import plot_3D_flyby_trajectory_only
from Interplanetary_quadruple import Trajectories_quadruple_2D, Trajectories_quadruple_3D

plt.style.use('dark_background')

# Constants
mu = 1.327e20 # m^3/s^2
AU = 149597870700  # 1 AU en metros


## DATES OF VOYAGER 2

# Departure from Earth
Y1 = 1977
M1 = 8
D1 = 20
utch1 = 14.0
utcm1 = 29.0
utcs1 = 44.0
JD1, JC1 = to_julian(Y1, M1, D1, utch1, utcm1, utcs1)

# FLYBY OF JUPITER
Y2 = 1979
M2 = 7
D2 = 9
utch2 = 0.0
utcm2 = 0.0
utcs2 = 0.0
JD2, JC2 = to_julian(Y2, M2, D2, utch2, utcm2, utcs2)

# FLYBY OF SATURN
Y3 = 1981
M3 = 8
D3 = 25
utch3 = 0.0
utcm3 = 0.0
utcs3 = 0.0
JD3, JC3 = to_julian(Y3, M3, D3, utch3, utcm3, utcs3)

# FLYBY OF URANUS
Y4 = 1986
M4 = 1
D4 = 24
utch4 = 0.0
utcm4 = 0.0
utcs4 = 0.0
JD4, JC4 = to_julian(Y4, M4, D4, utch4, utcm4, utcs4)

# FLYBY OF NEPTUNE
Y5 = 1989
M5 = 8
D5 = 25
utch5 = 0.0
utcm5 = 0.0
utcs5 = 0.0
JD5, JC5 = to_julian(Y5, M5, D5, utch5, utcm5, utcs5)


## TIME OF FLIGHT OF EACH TRAJECTORY

tof1 = (JD2 - JD1)*24*3600 # in s
tof2 = (JD3 - JD2)*24*3600 # in s
tof3 = (JD4 - JD3)*24*3600 # in s
tof4 = (JD5 - JD4)*24*3600 # in s

## CALCULATE EACH LAMBERT TRAJECTORY

# TRAJECTORY 1 (EARTH-JUPITER)
departure_planet1 = 3
arrival_planet1 = 5

plot_transfer_2D(JC1, JC2, departure_planet1, arrival_planet1, tof1)

h_transfer1, intersection_SOI_dep1, intersection_SOI_arr1, v_dep_transfer1, v_arr_transfer1, r_arr1, r_dep1, x_dep1, y_dep1, z_dep1, x_arr1, y_arr1, z_arr1, x_transfer_rot1, y_transfer_rot1, z_transfer_rot1 = plot_transfer_3D(JC1, JC2, departure_planet1, arrival_planet1, tof1)

print(h_transfer1)
print(intersection_SOI_dep1)
print(intersection_SOI_arr1)
print(v_dep_transfer1)
print(v_arr_transfer1)
print(r_arr1)

# TRAJECTORY 2 (JUPITER-SATURN)
departure_planet2 = 5
arrival_planet2 = 6

plot_transfer_2D(JC2, JC3, departure_planet2, arrival_planet2, tof2)

h_transfer2, intersection_SOI_dep2, intersection_SOI_arr2, v_dep_transfer2, v_arr_transfer2, r_arr2, r_dep2, x_dep2, y_dep2, z_dep2, x_arr2, y_arr2, z_arr2, x_transfer_rot2, y_transfer_rot2, z_transfer_rot2 = plot_transfer_3D(JC2, JC3, departure_planet2, arrival_planet2, tof2)

print(h_transfer2)
print(intersection_SOI_dep2)
print(intersection_SOI_arr2)
print(v_dep_transfer2)
print(v_arr_transfer2)
print(r_arr2)

# TRAJECTORY 3 (SATURN-URANUS)
departure_planet3 = 6
arrival_planet3 = 7

plot_transfer_2D(JC3, JC4, departure_planet3, arrival_planet3, tof3)

h_transfer3, intersection_SOI_dep3, intersection_SOI_arr3, v_dep_transfer3, v_arr_transfer3, r_arr3, r_dep3, x_dep3, y_dep3, z_dep3, x_arr3, y_arr3, z_arr3, x_transfer_rot3, y_transfer_rot3, z_transfer_rot3 = plot_transfer_3D(JC3, JC4, departure_planet3, arrival_planet3, tof3)

print(h_transfer3)
print(intersection_SOI_dep3)
print(intersection_SOI_arr3)
print(v_dep_transfer3)
print(v_arr_transfer3)
print(r_arr3)

# TRAJECTORY 4 (URANUS-NEPTUNE)
departure_planet4 = 7
arrival_planet4 = 8

plot_transfer_2D(JC4, JC5, departure_planet4, arrival_planet4, tof4)

h_transfer4, intersection_SOI_dep4, intersection_SOI_arr4, v_dep_transfer4, v_arr_transfer4, r_arr4, r_dep4, x_dep4, y_dep4, z_dep4, x_arr4, y_arr4, z_arr4, x_transfer_rot4, y_transfer_rot4, z_transfer_rot4 = plot_transfer_3D(JC4, JC5, departure_planet4, arrival_planet4, tof4)

print(h_transfer4)
print(intersection_SOI_dep4)
print(intersection_SOI_arr4)
print(v_dep_transfer4)
print(v_arr_transfer4)
print(r_arr4)


## COMPUTATION OF THE THREE GRAVITY ASSISTS

# JUPITER GRAVITY ASSIST
# PLANETOCENTRIC VELOCITY VECTOR 
planet_id = 5  # Jupiter
position_vec, velocity_vec, theta = state_vector(planet_id, JC2)

print(velocity_vec)

v_in = v_arr_transfer1 - velocity_vec
v_out = v_dep_transfer2 - velocity_vec

turning_angle1, deg1 = turning_angle(v_in, v_out)
print(f"Turning angle: {deg1:.2f}°")

# VELOCITY NORM AT ARRIVAL AND DEPARTURE OF INTERMEDIATE PLANET
V1 = np.linalg.norm(v_in)*1e-3
V2 = np.linalg.norm(v_out)*1e-3

print(V1)
print(V2)


# Constants
mu_planet = 1.26686534e8  
r_planet = 71492  # km (Jupiter's radius)
r_soi_planet = 48.2e6 # km (Jupiter's SOI)

r_periapsis1, Delta_V1, r_SOI1, a1_1, a2_1 = compute_swingby_parameters(V1, V2, mu_planet, turning_angle1, r_planet, r_soi_planet)
print(f"Periapsis Radius: {r_periapsis1:.2f} km")
print(f"Required Delta V: {Delta_V1:.2f} km/s")
plot_3D_flyby_trajectory_only(r_periapsis1, a1_1, a2_1, v_arr_transfer1, v_dep_transfer2, r_SOI=None)


# SATURN GRAVITY ASSIST
# PLANETOCENTRIC VELOCITY VECTOR 
planet_id = 6  # Saturn
position_vec, velocity_vec, theta = state_vector(planet_id, JC3)

print(velocity_vec)

v_in = v_arr_transfer2 - velocity_vec
v_out = v_dep_transfer3 - velocity_vec

turning_angle2, deg2 = turning_angle(v_in, v_out)
print(f"Turning angle: {deg2:.2f}°")

# VELOCITY NORM AT ARRIVAL AND DEPARTURE OF INTERMEDIATE PLANET
V1 = np.linalg.norm(v_in)*1e-3
V2 = np.linalg.norm(v_out)*1e-3

print(V1)
print(V2)


# Constants
mu_planet = 3.793e7 
r_planet = 60268  # km (Saturn's radius)
r_soi_planet = 54.47e6 # km (Saturn's SOI)

r_periapsis2, Delta_V2, r_SOI2, a1_2, a2_2 = compute_swingby_parameters(V1, V2, mu_planet, turning_angle2, r_planet, r_soi_planet)
print(f"Periapsis Radius: {r_periapsis2:.2f} km")
print(f"Required Delta V: {Delta_V2:.2f} km/s")
plot_3D_flyby_trajectory_only(r_periapsis2, a1_2, a2_2, v_arr_transfer2, v_dep_transfer3, r_SOI=None)


# URANUS GRAVITY ASSIST
# PLANETOCENTRIC VELOCITY VECTOR 
planet_id = 7  # Uranus
position_vec, velocity_vec, theta = state_vector(planet_id, JC4)

print(velocity_vec)

v_in = v_arr_transfer3 - velocity_vec
v_out = v_dep_transfer4 - velocity_vec

turning_angle3, deg3 = turning_angle(v_in, v_out)
print(f"Turning angle: {deg3:.2f}°")

# VELOCITY NORM AT ARRIVAL AND DEPARTURE OF INTERMEDIATE PLANET
V1 = np.linalg.norm(v_in)*1e-3
V2 = np.linalg.norm(v_out)*1e-3

print(V1)
print(V2)


# Constants
mu_planet = 5.794e6 
r_planet = 25.559  # km (Uranus's radius)
r_soi_planet = 51.49e6 # km (Uranus's SOI)

r_periapsis3, Delta_V3, r_SOI3, a1_3, a2_3 = compute_swingby_parameters(V1, V2, mu_planet, turning_angle3, r_planet, r_soi_planet)
print(f"Periapsis Radius: {r_periapsis3:.2f} km")
print(f"Required Delta V: {Delta_V3:.2f} km/s")
plot_3D_flyby_trajectory_only(r_periapsis3, a1_3, a2_3, v_arr_transfer3, v_dep_transfer4, r_SOI=None)



## PLOT TRAJECTORY (EARTH-JUPITER-SATURN-URANUS)

Trajectories_triple_3D(r_dep1, r_dep2, r_dep3, departure_planet1, departure_planet2, departure_planet3, r_arr1, r_arr2, r_arr3, arrival_planet1, arrival_planet2, arrival_planet3, x_dep1, y_dep1, z_dep1, x_dep2, y_dep2, z_dep2, x_dep3, y_dep3, z_dep3, x_arr1, y_arr1, z_arr1, x_arr2, y_arr2, z_arr2, x_arr3, y_arr3, z_arr3, x_transfer_rot1, y_transfer_rot1, z_transfer_rot1, x_transfer_rot2, y_transfer_rot2, z_transfer_rot2, x_transfer_rot3, y_transfer_rot3, z_transfer_rot3)
Trajectories_triple_2D(r_dep1, r_dep2, r_dep3, departure_planet1, departure_planet2, departure_planet3, r_arr1, r_arr2, r_arr3, arrival_planet1, arrival_planet2, arrival_planet3, x_dep1, y_dep1, x_dep2, y_dep2, x_dep3, y_dep3, x_arr1, y_arr1, x_arr2, y_arr2, x_arr3, y_arr3, x_transfer_rot1, y_transfer_rot1, x_transfer_rot2, y_transfer_rot2, x_transfer_rot3, y_transfer_rot3)



Trajectories_quadruple_3D(r_dep1, r_dep2, r_dep3, r_dep4, departure_planet1, departure_planet2, departure_planet3, departure_planet4, r_arr1, r_arr2, r_arr3, r_arr4, arrival_planet1, arrival_planet2, arrival_planet3, arrival_planet4, x_dep1, y_dep1, z_dep1, x_dep2, y_dep2, z_dep2, x_dep3, y_dep3, z_dep3, x_dep4, y_dep4, z_dep4, x_arr1, y_arr1, z_arr1, x_arr2, y_arr2, z_arr2, x_arr3, y_arr3, z_arr3, x_arr4, y_arr4, z_arr4, x_transfer_rot1, y_transfer_rot1, z_transfer_rot1, x_transfer_rot2, y_transfer_rot2, z_transfer_rot2, x_transfer_rot3, y_transfer_rot3, z_transfer_rot3, x_transfer_rot4, y_transfer_rot4, z_transfer_rot4)
Trajectories_quadruple_2D(r_dep1, r_dep2, r_dep3, r_dep4, departure_planet1, departure_planet2, departure_planet3, departure_planet4, r_arr1, r_arr2, r_arr3, r_arr4, arrival_planet1, arrival_planet2, arrival_planet3, arrival_planet4, x_dep1, y_dep1, x_dep2, y_dep2, x_dep3, y_dep3, x_dep4, y_dep4, x_arr1, y_arr1, x_arr2, y_arr2, x_arr3, y_arr3, x_arr4, y_arr4, x_transfer_rot1, y_transfer_rot1, x_transfer_rot2, y_transfer_rot2, x_transfer_rot3, y_transfer_rot3, x_transfer_rot4, y_transfer_rot4)
    














