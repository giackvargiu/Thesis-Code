
#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Improved gravity assist computation with numerical safety and better error handling.
"""

import numpy as np
import matplotlib.pyplot as plt
from Plot_hyperbola import plot_hyperbolic_trajectory

def safe_arcsin(x):
    return np.arcsin(np.clip(x, -1.0, 1.0))

def compute_swingby_parameters(vinf_minus, vinf_plus, mu_planet, delta_0, r_planet, r_soi_planet, tolerance=1e-1, max_iterations=100):

    # Semi-major axes
    a1 = mu_planet / vinf_minus**2
    a2 = mu_planet / vinf_plus**2

    # Sweep to find first guesses
    r_pi = np.linspace(0.001, r_soi_planet, 10000)
    half_delta_1 = safe_arcsin(a1 / (r_pi + a1))
    half_delta_2 = safe_arcsin(a2 / (r_pi + a2))
    half_delta_0 = delta_0 / 2

    half_delta_1_deg = np.degrees(half_delta_1)
    half_delta_2_deg = np.degrees(half_delta_2)
    half_delta_0_deg = np.degrees(half_delta_0)

    # Plot sweep
    plt.figure(figsize=(8, 6))
    plt.plot(r_pi, half_delta_1_deg, label=r'$\delta_1/2$ (Inbound Half-Turn Angle)')
    plt.plot(r_pi, half_delta_2_deg, label=r'$\delta_2/2$ (Outbound Half-Turn Angle)')
    plt.axhline(y=half_delta_0_deg, color='r', linestyle='--', label=r'$\delta_0/2$ (Target)')
    plt.axvline(x=r_planet, color='g', linestyle='--', label='Planet Radius')
    plt.axvline(x=r_soi_planet, color='b', linestyle='--', label='Planet SOI')
    plt.xscale('log')
    plt.xlabel('Periapsis Radius (km)')
    plt.ylabel('Half Turning Angle (degrees)')
    plt.title('Half Turning Angles vs. Periapsis Radius')
    plt.legend()
    plt.grid(which='both', linestyle='--', linewidth=0.5)
    plt.show()

    # Initial guess
    idx_1 = np.argmin(np.abs(half_delta_1_deg - half_delta_0_deg))
    idx_2 = np.argmin(np.abs(half_delta_2_deg - half_delta_0_deg))
    r_intersect_1 = r_pi[idx_1]
    r_intersect_2 = r_pi[idx_2]
    r_periapsis = (r_intersect_1 + r_intersect_2) / 2

    # Newton-Raphson iteration
    iteration = 0
    while iteration < max_iterations:
        denom1 = r_periapsis + a1
        denom2 = r_periapsis + a2

        if denom1 <= 0 or denom2 <= 0:
            print("Warning: invalid radius during iteration.")
            break

        f = safe_arcsin(a1 / denom1) + safe_arcsin(a2 / denom2) - delta_0
        df_dr = -(a1 / denom1) / np.sqrt(r_periapsis**2 + 2*a1*r_periapsis) - (a2 / denom2) / np.sqrt(r_periapsis**2 + 2*a2*r_periapsis)

        if abs(df_dr) < 1e-8:
            print("Warning: df/dr near zero, breaking iteration.")
            break

        r_new = r_periapsis - f / df_dr
        if abs(r_new - r_periapsis) < tolerance:
            r_periapsis = r_new
            break

        r_periapsis = r_new
        iteration += 1

    # Final Delta-V
    if r_periapsis > 1e-8:
        term1 = vinf_minus**2 - (2 * mu_planet / r_periapsis)
        term2 = vinf_plus**2 - (2 * mu_planet / r_periapsis)
        v_pi_minus = np.sqrt(max(term1, 0))
        v_pi_plus = np.sqrt(max(term2, 0))
    else:
        print("Warning: r_periapsis is zero or too small.")
        v_pi_minus = 0
        v_pi_plus = 0

    Delta_V = abs(v_pi_minus - v_pi_plus)
    
    # Safety check on periapsis
    if r_periapsis < r_planet or r_periapsis > r_soi_planet:
        print("Warning: Final periapsis is outside expected bounds.")
        return r_periapsis, 60.0, r_soi_planet, a1, a2

    # Diagnostic plot
    plt.figure(figsize=(8, 6))
    plt.plot(r_pi, half_delta_1_deg, label=r'$\delta_1/2$')
    plt.plot(r_pi, half_delta_2_deg, label=r'$\delta_2/2$')
    plt.axhline(half_delta_0_deg, color='r', linestyle='--')
    plt.scatter([r_periapsis], [half_delta_0_deg], color='purple', label='Final r_periapsis')
    plt.xscale('log')
    plt.grid()
    plt.legend()
    plt.title("Newton-Raphson Solution")
    plt.xlabel("Periapsis Radius (km)")
    plt.ylabel("Turning Angle (deg)")
    plt.show()

    plot_hyperbolic_trajectory(r_periapsis, a1, a2, r_soi_planet)

    return Delta_V
