import matplotlib.pyplot as plt
from functions_plan import to_julian, position, plot_orbits

# Insert the initial (departure) date here (1st planet)
Y1 = 1975
M1 = 8
D1 = 20
utch1 = 0.0
utcm1 = 0.0
utcs1 = 0.0
JD1, JC1 = to_julian(Y1, M1, D1, utch1, utcm1, utcs1)

plt.style.use('dark_background')

# File path for the database of asteroids
file_path = "Databases/astorb_200.txt" 
planets = position(JC1)

plot_orbits(planets, D1, M1, Y1, utch=0, utcm=0, utcs=0)

# 2. Inner planets: Mercury (1), Venus (2), Earth (3), Mars (4)
inner_planets = {k: planets[k] for k in (1, 2, 3, 4)}
plot_orbits(inner_planets, D1, M1, Y1, utch=0, utcm=0, utcs=0)

# 3. Outer planets: Jupiter (5), Saturn (6), Uranus (7), Neptune (8)
outer_planets = {k: planets[k] for k in (5, 6, 7, 8)}
plot_orbits(outer_planets, D1, M1, Y1, utch=0, utcm=0, utcs=0)