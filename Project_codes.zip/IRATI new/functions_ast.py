import math
import numpy as np
import matplotlib.pyplot as plt

def asteroid_data(file_path):
    asteroid_data = []  # lista para guardar los datos extraídos
    with open(file_path, "r") as file:
        for line in file:
            # Saltar líneas vacías
            if not line.strip():
                continue

            data = line.split()

            # Extraer los datos contando desde el final:
            # Los 7 últimos campos relevantes (de derecha a izquierda):
            # - data[-17]: Epoch (yyyymmdd)
            # - data[-16]: Mean anomaly [deg]
            # - data[-15]: Argument of perihelion [deg]
            # - data[-14]: Longitude of ascending node [deg]
            # - data[-13]: Inclination [deg]
            # - data[-12]: Eccentricity
            # - data[-11]: Semimajor axis [AU]
            try:
                epoch = data[-17]
                mean_anomaly = float(data[-16])
                arg_perihelion = float(data[-15])
                lon_asc_node = float(data[-14])
                inclination = float(data[-13])
                eccentricity = float(data[-12])
                semimajor_axis = float(data[-11])
            except (IndexError, ValueError):
                # Si ocurre algún error, se descarta la línea
                continue

            # Guardar los campos extraídos en un diccionario
            new_data = {
                "Epoch": epoch,
                "Mean anomaly": mean_anomaly,
                "Argument of perihelion": arg_perihelion,
                "Longitude of ascending node": lon_asc_node,
                "Inclination": inclination,
                "Eccentricity": eccentricity,
                "Semimajor axis": semimajor_axis
            }

            asteroid_data.append(new_data)
    return asteroid_data


def to_asteroids_OP(data):
    """
    Transforma una lista de diccionarios con datos de asteroides en una lista de listas
    siguiendo la estructura:   
    [a, 0, e, 0, i, 0, Omega, 0, omega, 0, L, 0]
    """
    transformed = []
    for entry in data:
        semimajor = entry.get("Semimajor axis")
        eccentricity = entry.get("Eccentricity")
        inclination = entry.get("Inclination")
        lon_asc_node = entry.get("Longitude of ascending node")
        arg_perihelion = entry.get("Argument of perihelion")
        mean_anomaly = entry.get("Mean anomaly")
        
        # Calcular la suma de Mean anomaly y Argument of perihelion
        mean_long = mean_anomaly + arg_perihelion
        
        # Crear la lista según la estructura requerida
        new_entry = [
            semimajor, 0,
            eccentricity, 0,
            inclination, 0,
            lon_asc_node, 0,
            arg_perihelion, 0,
            mean_long, 0
        ]
        
        transformed.append(new_entry)
    
    return transformed


def propagation(E, E_dot, jul_cent):
    return E + E_dot * jul_cent

def angular_momentum(mu, a, e):
    return math.sqrt(mu * a * (1 - e**2))

def mean_anomaly(omega_prop, L_prop):
    return L_prop - omega_prop

def arg_per(omega_prop, Omega_prop):
    return omega_prop - Omega_prop

def true_anomaly(e, E):
    return 2.0 * math.atan(math.tan(E / 2.0) * math.sqrt((1 + e) / (1 - e)))

def kepler(M, E, e):
    return E - e * np.sin(E) - M

def kepler_der(E, e):
    return 1.0 - e * np.cos(E)

def newton_raphson(M, e, N, eps):
    x0 = M
    for _ in range(N):
        x1 = x0 - kepler(M, x0, e) / kepler_der(x0, e)
        if abs(x1 - x0) < eps:
            return x1
        x0 = x1
    return x0

def rotational_matrix(Omega, omega, inclination):
    R = np.zeros((3, 3))
    R[0, 0] = np.cos(Omega)*np.cos(omega) - np.sin(Omega)*np.cos(inclination)*np.sin(omega)
    R[0, 1] = -np.cos(Omega)*np.sin(omega) - np.sin(Omega)*np.cos(inclination)*np.cos(omega)
    R[0, 2] = np.sin(Omega)*np.sin(inclination)
    R[1, 0] = np.sin(Omega)*np.cos(omega) + np.cos(Omega)*np.cos(inclination)*np.sin(omega)
    R[1, 1] = -np.sin(Omega)*np.sin(omega) + np.cos(Omega)*np.cos(inclination)*np.cos(omega)
    R[1, 2] = -np.cos(Omega)*np.sin(inclination)
    R[2, 0] = np.sin(inclination)*np.sin(omega)
    R[2, 1] = np.sin(inclination)*np.cos(omega)
    R[2, 2] = np.cos(inclination)
    return R
    
def state_vector_ast(asteroid_data, jul_cent):
    # Constantes
    mu = 1.32712440018e20
    Au = 149597870700

    # Parámetros orbitales
    # Como no estamos teniendo en cuenta el cambio de parámetros en el tiempo,
    # a_dot=0 y a_prop=a
    # No hace falta propagar los parámetros orbitales
    a      = asteroid_data[0] * Au # [m]
    e      = asteroid_data[2]
    i      = math.radians(asteroid_data[4]) # [rad]
    Omega  = np.mod(math.radians(asteroid_data[6]), 2*math.pi) # módulo en rad
    omega  = np.mod(math.radians(asteroid_data[8]), 2*math.pi)
    L      = np.mod(math.radians(asteroid_data[10]), 2*math.pi)

    # Cálculo del momento angular, anomalía media y argumento del perihelio
    h = angular_momentum(mu, a, e)
    omega_2 = np.mod(arg_per(omega, Omega), 2*math.pi)
    M = mean_anomaly(omega, L)

    # Resolver la ecuación de Kepler usando el método de Newton-Raphson
    N_iter = 10000000
    eps = 1e-12
    E = newton_raphson(M, e, N_iter, eps)

    # Anomalía verdadera
    theta = true_anomaly(e, E)

    # Calcular el vector posición
    r = np.zeros(3)
    r0 = (h**2 / mu) / (1.0 + e * np.cos(theta))
    r[0] = r0 * np.cos(theta)
    r[1] = r0 * np.sin(theta)
    r[2] = 0.0

    # Calcular el vector velocidad
    v = np.zeros(3)
    v[0] = -(mu / h) * np.sin(theta)
    v[1] = (mu / h) * (e + np.cos(theta))
    v[2] = 0.0

    # Aplicar la matriz de rotación para obtener el estado en el sistema de referencia inercial
    R = rotational_matrix(Omega, omega_2, i)
    r = np.dot(R, r)
    v = np.dot(R, v)

    return r, v, theta

def position_ast(julian_century, file_path):
    data = asteroid_data(file_path)
    asteroids_OP = to_asteroids_OP(data)
    asteroids = {}
    # Cálculo de las posiciones de cada planeta usando la función `asteroids_OP`
    for i in range(0, len(asteroids_OP)):
        r, v, theta = state_vector_ast(asteroids_OP[i], julian_century)
        asteroids[i] = r
    return asteroids


def plot_asteroids(asteroids, day, month, year):
    # Diccionarios de nombres y colores para los planetas

    fig, ax = plt.subplots(figsize=(8, 8))
    Au = 149597870700  # 1 AU en metros
    
    # Representar el Sol con una estrella amarilla
    ax.plot(0, 0, marker='*', color='yellow', markersize=12, markerfacecolor='none', linestyle='None', label='Sun')
    
    # Graficar la posición actual y la órbita circular de cada planeta (convertido a AU)
    for i in sorted(asteroids.keys()):
        r = asteroids[i]
        # Convertir la posición de metros a AU
        r_Au = r / Au
        # Posición actual del planeta en AU
        ax.plot(r_Au[0], r_Au[1], 'o', color='white', markersize=0.5)
    
    ax.set_aspect('equal', 'box')
    ax.set_xlabel('X [Au]')
    ax.set_ylabel('Y [Au]')
    
    # Establecer límites en los ejes x e y
    ax.set_xlim(-5, 5)
    ax.set_ylim(-5, 5)
    
    ax.set_title('Asteroids of the Solar System')
    plt.show()
