#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Mon Apr 28 11:50:08 2025

@author: giacomovargiu
"""

import numpy as np
from datetime import datetime, timedelta
import numpy as np
import matplotlib.pyplot as plt
from functions_plan import to_julian, state_vector
from ANGLE import turning_angle
from Gravity_Assist import compute_swingby_parameters
from Interplanetary_triple import Trajectories_triple_3D, Trajectories_triple_2D
from Swingby_3D import plot_3D_flyby_trajectory_only
from Interplanetary_quadruple import Trajectories_quadruple_2D, Trajectories_quadruple_3D
from Lambert import Lambert_3D

# Placeholder imports for your helper functions
# from your_helpers import Julian_date, Planetary_parameters_FINALPROJECT, find_z_LOUISON, func_delta_t_z, Terminal_Velocities_Method1

def main_pcp(Planet_index_2, n, DeltaT_min, DeltaT_Max):
    # Constants
    Planet_index_1 = 3
    mu_sun = 1.327e20  # Gravitational parameter of the Sun, m^3/s^2
    AU = 1.495978707e11  # Astronomical Unit in meters
    n_rev = 0  # Number of revolutions
    tm = 1  # Transfer type

    # Departure dates
    t1 = datetime.strptime('2020-01-01', '%Y-%m-%d')
    t2 = datetime.strptime('2025-01-01', '%Y-%m-%d')

    launch_dates = np.linspace(t1.timestamp(), t2.timestamp(), n)
    launch_dates = [datetime.fromtimestamp(ts) for ts in launch_dates]

    deltaT_days = np.linspace(DeltaT_min, DeltaT_Max, n)

    # Initialize Delta-V matrix
    Delta_V_matrix = np.zeros((n, n))

    for i in range(n):
        for j in range(n):
            launch_date = launch_dates[i]
            delta_t_days = deltaT_days[j]
            arrival_date = launch_date + timedelta(days=delta_t_days)

            print(f'Launch Date: {launch_date.strftime("%Y-%m-%d")}')
            print(f'Arrival Date: {arrival_date.strftime("%Y-%m-%d")}')

            # Julian dates
            JD_launch, JC_launch = to_julian(launch_date)
            JD_arrival, JC_arrival = to_julian(arrival_date)

            # Planetary parameters
            R1, V_planet_1, theta_1 = state_vector(JC_launch, Planet_index_1)
            R2, V_planet_2, theta_2 = state_vector(JC_arrival, Planet_index_2)

            h_transfer, intersection_SOI_dep, intersection_SOI_arr, V1, V2, r_arr, r_dep, x_dep, y_dep, z_dep, x_arr, y_arr, z_arr, x_transfer_rot, y_transfer_rot, z_transfer_rot = Lambert_3D(JC_launch, JC_arrival, Planet_index_1, Planet_index_2, delta_t_days)


            # Compute Delta V
            Delta_V1 = np.linalg.norm(V1 - V_planet_1)
            Delta_V2 = np.linalg.norm(V_planet_2 - V2)
            Delta_V = Delta_V1 + Delta_V2

            print(f'Delta V1: {Delta_V1:.2f} m/s')
            print(f'Delta V2: {Delta_V2:.2f} m/s')
            print(f'Total Delta V: {Delta_V:.2f} m/s')

            # Store results
            Delta_V_matrix[i, j] = Delta_V

    # Limit the values in Delta_V_matrix to 50 km/s
    Delta_V_matrix_limited = np.minimum(Delta_V_matrix * 1e-3, 50)  # Convert to km/s

    return Delta_V_matrix_limited, launch_dates, deltaT_days

# Example call (assuming helper functions exist)
# Delta_V_matrix_limited, launchDates, deltaT_days = main_pcp(4, 10, 100, 300)
