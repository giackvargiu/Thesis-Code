#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Apr 29 23:16:20 2025

@author: giacomovargiu
"""

import numpy as np
import matplotlib.pyplot as plt
from functions_transf import data_plots

def Trajectories_quadruple_3D(r_dep, r_dep2, r_dep3, r_dep4, departure_planet, departure_planet2, departure_planet3, departure_planet4, r_arr, r_arr2, r_arr3, r_arr4, arrival_planet, arrival_planet2, arrival_planet3, arrival_planet4, x_dep, y_dep, z_dep, x_dep2, y_dep2, z_dep2, x_dep3, y_dep3, z_dep3, x_dep4, y_dep4, z_dep4, x_arr, y_arr, z_arr, x_arr2, y_arr2, z_arr2, x_arr3, y_arr3, z_arr3, x_arr4, y_arr4, z_arr4, x_transfer_rot, y_transfer_rot, z_transfer_rot, x_transfer_rot2, y_transfer_rot2, z_transfer_rot2, x_transfer_rot3, y_transfer_rot3, z_transfer_rot3, x_transfer_rot4, y_transfer_rot4, z_transfer_rot4):
    
    # Data
    AU, mu, planet_names, colors, planet_masses, sun_mass = data_plots()
    
    
    # Configurar la figura y el eje 3D con fondo negro
    fig = plt.figure(figsize=(8, 6))
    ax = fig.add_subplot(111, projection='3d', facecolor='black')
    # Representar el Sol en el origen
    ax.plot(0, 0, 0, marker='*', color='yellow', markersize=15,
            markerfacecolor='none', linestyle='None', label='Sun')
    
    ## Primera traiectoria
    # Graficar la posición actual del planeta de partida
    ax.plot(r_dep[0]/AU, r_dep[1]/AU, r_dep[2]/AU, 'o', 
            color=colors[departure_planet], markersize=8, label=planet_names[departure_planet])
    # Graficar la posición actual del planeta de llegada
    ax.plot(r_arr[0]/AU, r_arr[1]/AU, r_arr[2]/AU, 'o', 
            color=colors[arrival_planet], markersize=8, label=planet_names[arrival_planet])
    # Graficar la órbita de partida con línea fina y discontinua
    ax.plot(x_dep, y_dep, z_dep, color=colors[departure_planet], linewidth=0.7, linestyle='--')
    # Graficar la órbita de llegada con línea fina y discontinua
    ax.plot(x_arr, y_arr, z_arr, color=colors[arrival_planet], linewidth=0.7, linestyle='--')
    # Graficar la órbita de transferencia 
    ax.plot(x_transfer_rot/AU, y_transfer_rot/AU, z_transfer_rot/AU, '-', color='white', linewidth=0.5)
    
    
    ## Segunda traiectoria
    # Graficar la posición actual del planeta de llegada
    ax.plot(r_arr2[0]/AU, r_arr2[1]/AU, r_arr2[2]/AU, 'o', 
            color=colors[arrival_planet2], markersize=8, label=planet_names[arrival_planet2])
    # Graficar la órbita de partida con línea fina y discontinua
    ax.plot(x_dep2, y_dep2, z_dep2, color=colors[departure_planet2], linewidth=0.7, linestyle='--')
    # Graficar la órbita de llegada con línea fina y discontinua
    ax.plot(x_arr2, y_arr2, z_arr2, color=colors[arrival_planet2], linewidth=0.7, linestyle='--')
    # Graficar la órbita de transferencia 
    ax.plot(x_transfer_rot2/AU, y_transfer_rot2/AU, z_transfer_rot2/AU, '-', color='white', linewidth=0.5)
    
    
    ## Tercera traiectoria
    # Graficar la posición actual del planeta de llegada
    ax.plot(r_arr3[0]/AU, r_arr3[1]/AU, r_arr3[2]/AU, 'o', 
            color=colors[arrival_planet3], markersize=8, label=planet_names[arrival_planet3])
    # Graficar la órbita de partida con línea fina y discontinua
    ax.plot(x_dep3, y_dep3, z_dep3, color=colors[departure_planet3], linewidth=0.7, linestyle='--')
    # Graficar la órbita de llegada con línea fina y discontinua
    ax.plot(x_arr3, y_arr3, z_arr3, color=colors[arrival_planet3], linewidth=0.7, linestyle='--')
    # Graficar la órbita de transferencia 
    ax.plot(x_transfer_rot3/AU, y_transfer_rot3/AU, z_transfer_rot3/AU, '-', color='white', linewidth=0.5)
    
    
    ## Tercera traiectoria
    # Graficar la posición actual del planeta de llegada
    ax.plot(r_arr4[0]/AU, r_arr4[1]/AU, r_arr4[2]/AU, 'o', 
            color=colors[arrival_planet4], markersize=8, label=planet_names[arrival_planet4])
    # Graficar la órbita de partida con línea fina y discontinua
    ax.plot(x_dep4, y_dep4, z_dep4, color=colors[departure_planet4], linewidth=0.7, linestyle='--')
    # Graficar la órbita de llegada con línea fina y discontinua
    ax.plot(x_arr4, y_arr4, z_arr4, color=colors[arrival_planet4], linewidth=0.7, linestyle='--')
    # Graficar la órbita de transferencia 
    ax.plot(x_transfer_rot4/AU, y_transfer_rot4/AU, z_transfer_rot4/AU, '-', color='white', linewidth=0.5)
    
    
    # Personalizar el fondo y los ejes
    ax.xaxis.pane.set_facecolor((0, 0, 0, 0))
    ax.yaxis.pane.set_facecolor((0, 0, 0, 0))
    ax.zaxis.pane.set_facecolor((0, 0, 0, 0))
    ax.xaxis.label.set_color('white')
    ax.yaxis.label.set_color('white')
    ax.zaxis.label.set_color('white')
    ax.title.set_color('white')
    ax.tick_params(colors='white')
    ax.grid(False)

    # Configurar etiquetas y título
    ax.set_xlabel('X (UA)')
    ax.set_ylabel('Y (UA)')
    ax.set_zlabel('Z (UA)')
    # ax.set_title(f"Transfer orbit from {planet_names[departure_planet]} to {planet_names[arrival_planet]} with TOF: {(tof_sec/24/3600):.1f} days")
    ax.legend()

    # Mostrar la gráfica
    plt.show()
    
    
    
def Trajectories_quadruple_2D(r_dep, r_dep2, r_dep3, r_dep4, departure_planet, departure_planet2, departure_planet3, departure_planet4, r_arr, r_arr2, r_arr3, r_arr4, arrival_planet, arrival_planet2, arrival_planet3, arrival_planet4, x_dep, y_dep, x_dep2, y_dep2, x_dep3, y_dep3, x_dep4, y_dep4, x_arr, y_arr, x_arr2, y_arr2, x_arr3, y_arr3, x_arr4, y_arr4, x_transfer_rot, y_transfer_rot, x_transfer_rot2, y_transfer_rot2, x_transfer_rot3, y_transfer_rot3, x_transfer_rot4, y_transfer_rot4):
    
    # Data
    AU, mu, planet_names, colors, planet_masses, sun_mass = data_plots()
    
    # Configurar la figura y el eje 3D con fondo negro
    fig, ax = plt.subplots(figsize=(8, 8))
    # Representar el Sol en el origen
    ax.plot(0, 0, marker='*', color='yellow', markersize=15,
            markerfacecolor='none', linestyle='None', label='Sun')
    
    
    ## Primera traiectoria
    # Graficar la posición actual del planeta de partida
    ax.plot(r_dep[0]/AU, r_dep[1]/AU, 'o', 
            color=colors[departure_planet], markersize=8, label=planet_names[departure_planet])
    # Graficar la posición actual del planeta de llegada
    ax.plot(r_arr[0]/AU, r_arr[1]/AU, 'o', 
            color=colors[arrival_planet], markersize=8, label=planet_names[arrival_planet])
    # Graficar la órbita de partida con línea fina y discontinua
    ax.plot(x_dep, y_dep, color=colors[departure_planet], linewidth=0.7, linestyle='--')
    # Graficar la órbita de llegada con línea fina y discontinua
    ax.plot(x_arr, y_arr, color=colors[arrival_planet], linewidth=0.7, linestyle='--')
    # Graficar la órbita de transferencia
    ax.plot(x_transfer_rot/AU, y_transfer_rot/AU, '-', color='white', linewidth=0.5)
    
    
    ## Segunda traiectoria
    # Graficar la posición actual del planeta de llegada
    ax.plot(r_arr2[0]/AU, r_arr2[1]/AU, 'o', 
            color=colors[arrival_planet2], markersize=8, label=planet_names[arrival_planet2])
    # Graficar la órbita de partida con línea fina y discontinua
    ax.plot(x_dep2, y_dep2, color=colors[departure_planet2], linewidth=0.7, linestyle='--')
    # Graficar la órbita de llegada con línea fina y discontinua
    ax.plot(x_arr2, y_arr2, color=colors[arrival_planet2], linewidth=0.7, linestyle='--')
    # Graficar la órbita de transferencia
    ax.plot(x_transfer_rot2/AU, y_transfer_rot2/AU, '-', color='white', linewidth=0.5)
    
    
    ## Tercera traiectoria
    # Graficar la posición actual del planeta de llegada
    ax.plot(r_arr3[0]/AU, r_arr3[1]/AU, 'o', 
            color=colors[arrival_planet3], markersize=8, label=planet_names[arrival_planet3])
    # Graficar la órbita de partida con línea fina y discontinua
    ax.plot(x_dep3, y_dep3, color=colors[departure_planet3], linewidth=0.7, linestyle='--')
    # Graficar la órbita de llegada con línea fina y discontinua
    ax.plot(x_arr3, y_arr3, color=colors[arrival_planet3], linewidth=0.7, linestyle='--')
    # Graficar la órbita de transferencia
    ax.plot(x_transfer_rot3/AU, y_transfer_rot3/AU, '-', color='white', linewidth=0.5)
    
    
    ## Tercera traiectoria
    # Graficar la posición actual del planeta de llegada
    ax.plot(r_arr4[0]/AU, r_arr4[1]/AU, 'o', 
            color=colors[arrival_planet4], markersize=8, label=planet_names[arrival_planet4])
    # Graficar la órbita de partida con línea fina y discontinua
    ax.plot(x_dep4, y_dep4, color=colors[departure_planet4], linewidth=0.7, linestyle='--')
    # Graficar la órbita de llegada con línea fina y discontinua
    ax.plot(x_arr4, y_arr4, color=colors[arrival_planet4], linewidth=0.7, linestyle='--')
    # Graficar la órbita de transferencia
    ax.plot(x_transfer_rot4/AU, y_transfer_rot4/AU, '-', color='white', linewidth=0.5)
    
    
    # Personalizar el fondo y los ejes
    ax.xaxis.label.set_color('white')
    ax.yaxis.label.set_color('white')
    ax.title.set_color('white')
    ax.tick_params(colors='white')
    ax.grid(False)
    
    # Configurar etiquetas y título
    ax.set_xlabel('X (UA)')
    ax.set_ylabel('Y (UA)')
    #ax.set_title(f"Transfer orbit from {planet_names[departure_planet]} to {planet_names[arrival_planet]} with TOF: {(tof_sec/24/3600):.1f} days")
    ax.legend()
    # Mostrar la gráfica
    plt.show()
    
def rotation_matrix_from_vinfs(v_in, v_out):
    v_in = v_in / np.linalg.norm(v_in)
    cross = np.cross(v_in, v_out)
    z_hat = cross / np.linalg.norm(cross)
    y_hat = np.cross(z_hat, v_in)
    x_hat = v_in
    return np.column_stack((x_hat, y_hat, z_hat))


def generate_hyperbola_2d(a, e, theta_range):
    r = a * (e**2 - 1) / (1 + e * np.cos(theta_range))
    x = r * np.cos(theta_range)
    y = r * np.sin(theta_range)
    z = np.zeros_like(x)
    return np.vstack((x, y, z))